
#include "PrepareStatement.h"

namespace hsql {
  // PrepareStatement
  PrepareStatement::PrepareStatement() :
    SQLStatement(kStmtPrepare),
    name(0),
    query(0) {}

  PrepareStatement::~PrepareStatement() {
    free(name);
    free(query);
  }
} // namespace hsql
