
#include "statements.h"

namespace hsql {

  // ColumnDefinition
  ColumnDefinition::ColumnDefinition(char* name, DataType type) :
    name(name),
    type(type) {};

  ColumnDefinition::~ColumnDefinition() {
    free(name);
  }

  // CreateStatemnet
  CreateStatement::CreateStatement(CreateType type) :
    SQLStatement(kStmtCreate),
    type(type),
    ifNotExists(false),
    filePath(0),
    schema(0),
    tableName(0),
    columns(0),
    viewColumns(0),
    select(0) {};

  CreateStatement::~CreateStatement() {
    free(filePath);
    free(schema);
    free(tableName);
    delete select;

    if (columns != 0) {
		for (int var = 0; var < columns->size(); ++var) {
			delete columns->at(var);
		}
		//for (ColumnDefinition* def : *columns) {        delete def;      }
      delete columns;
    }

    if (viewColumns != 0) {
		for (int var = 0; var < viewColumns->size(); ++var) {
			delete viewColumns ->at(var);
		}

		//for (char* column : *viewColumns) {        free(column);      }
      delete viewColumns;
    }
  }

  // DeleteStatement
  DeleteStatement::DeleteStatement() :
    SQLStatement(kStmtDelete),
    schema(0),
    tableName(0),
    expr(0) {};

  DeleteStatement::~DeleteStatement() {
    free(schema);
    free(tableName);
    delete expr;
  }

  // DropStatament
  DropStatement::DropStatement(DropType type) :
    SQLStatement(kStmtDrop),
    type(type),
    schema(0),
    name(0) {}

  DropStatement::~DropStatement() {
    free(schema);
    free(name);
  }

  // ExecuteStatement
  ExecuteStatement::ExecuteStatement() :
    SQLStatement(kStmtExecute),
    name(0),
    parameters(0) {}

  ExecuteStatement::~ExecuteStatement() {
    free(name);

    if (parameters != 0) {
		for (int var = 0; var < parameters->size(); ++var) {
			delete parameters->at(var);
		}
		//for (Expr* param : *parameters) {        delete param;      }
      delete parameters;
    }
  }

  // ImportStatement
  ImportStatement::ImportStatement(ImportType type) :
    SQLStatement(kStmtImport),
    type(type),
    filePath(0),
    schema(0),
    tableName(0) {};

  ImportStatement::~ImportStatement() {
    free(filePath);
    free(schema);
    free(tableName);
  }

  // InsertStatement
  InsertStatement::InsertStatement(InsertType type) :
    SQLStatement(kStmtInsert),
    type(type),
    schema(0),
    tableName(0),
    columns(0),
    values(0),
    select(0) {}

  InsertStatement::~InsertStatement() {
    free(schema);
    free(tableName);
    delete select;

    if (columns != 0) {
		for (int var = 0; var < columns->size(); ++var) {
			free(columns->at(var));
		}
		//for (char* column : *columns) {        free(column);      }
      delete columns;
    }

    if (values != 0) {
		for (int var = 0; var < values->size(); ++var) {
			delete values->at(var);
		}
		//for (Expr* expr : *values) {        delete expr;      }
      delete values;
    }
  }

  // ShowStatament
  ShowStatement::ShowStatement(ShowType type) :
    SQLStatement(kStmtShow),
    type(type),
    schema(0),
    name(0) {}

  ShowStatement::~ShowStatement() {
    free(schema);
    free(name);
  }

  // SelectStatement.h

  // OrderDescription
  OrderDescription::OrderDescription(OrderType type, Expr* expr) :
    type(type),
    expr(expr) {}

  OrderDescription::~OrderDescription() {
    delete expr;
  }

  // LimitDescription
  LimitDescription::LimitDescription(int64_t limit, int64_t offset) :
    limit(limit),
    offset(offset) {}

  // GroypByDescription
  GroupByDescription::GroupByDescription() :
    columns(0),
    having(0) {}

  GroupByDescription::~GroupByDescription() {
    delete having;

    if (columns != 0) {
		for (int var = 0; var < columns->size(); ++var) {
			delete columns->at(var);
		}
		//for (Expr* expr : *columns) {        delete expr;      }
      delete columns;
    }
  }

  // SelectStatement
  SelectStatement::SelectStatement() :
    SQLStatement(kStmtSelect),
    fromTable(0),
    selectDistinct(false),
    selectList(0),
    whereClause(0),
    groupBy(0),
    unionSelect(0),
    order(0),
    limit(0) {};

  SelectStatement::~SelectStatement() {
    delete fromTable;
    delete whereClause;
    delete groupBy;
    delete unionSelect;
    delete limit;

    // Delete each element in the select list.
    if (selectList != 0) {
		for (int var = 0; var < selectList->size(); ++var) {
			delete selectList->at(var);
		}
		//for (Expr* expr : *selectList) {        delete expr;      }
      delete selectList;
    }

    if (order != 0) {
		for (int var = 0; var < order->size(); ++var) {
			delete order->at(var);
		}
		//for (OrderDescription* desc : *order) {        delete desc;      }
      delete order;
    }
  }

  // UpdateStatement
  UpdateStatement::UpdateStatement() :
    SQLStatement(kStmtUpdate),
    table(0),
    updates(0),
    where(0) {}

  UpdateStatement::~UpdateStatement() {
    delete table;
    delete where;

	  if (updates != 0) {
		UpdateClause* update;
		for (int var = 0; var < updates->size(); ++var) {
			update = updates->at(var);
			free(update->column);
			delete update->value;
			delete update;
      }
      delete updates;
    }
  }

  // TableRef
  TableRef::TableRef(TableRefType type) :
    type(type),
    schema(0),
    name(0),
    alias(0),
    select(0),
    list(0),
    join(0) {}

  TableRef::~TableRef() {
    free(schema);
    free(name);
    free(alias);

    delete select;
    delete join;

    if (list != 0) {
		for (int var = 0; var < list->size(); ++var) {
			delete list->at(var);
//		}
//      for (TableRef* table : *list) {
//        delete table;
      }
      delete list;
    }
  }

  bool TableRef::hasSchema() const {
    return schema != 0;
  }

  const char* TableRef::getName() const {
    if (alias != 0) return alias;
    else return name;
  }

  // JoinDefinition
  JoinDefinition::JoinDefinition() :
    left(0),
    right(0),
    condition(0),
    type(kJoinInner) {}

  JoinDefinition::~JoinDefinition() {
    delete left;
    delete right;
    delete condition;
  }

} // namespace hsql
