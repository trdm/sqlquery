/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 2

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Substitute the type names.  */
#define YYSTYPE         HSQL_STYPE
#define YYLTYPE         HSQL_LTYPE
/* Substitute the variable and function names.  */
#define yyparse         hsql_parse
#define yylex           hsql_lex
#define yyerror         hsql_error
#define yydebug         hsql_debug
#define yynerrs         hsql_nerrs

/* First part of user prologue.  */

/**
 * bison_parser.y
 * defines bison_parser.h
 * outputs bison_parser.c
 *
 * Grammar File Spec: http://dinosaur.compilertools.net/bison/bison_6.html
 *
 */
/*********************************
 ** Section 1: C Declarations
 *********************************/

#include "bison_parser.h"
#include "flex_lexer.h"

#include <stdio.h>
#include <string.h>

using namespace hsql;

int yyerror(YYLTYPE* llocp, SQLParserResult* result, yyscan_t scanner, const char *msg) {
	result->setIsValid(false);
	result->setErrorDetails(strdup(msg), llocp->first_line, llocp->first_column);
	return 0;
}



# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "bison_parser.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_IDENTIFIER = 3,                 /* IDENTIFIER  */
  YYSYMBOL_STRING = 4,                     /* STRING  */
  YYSYMBOL_FLOATVAL = 5,                   /* FLOATVAL  */
  YYSYMBOL_INTVAL = 6,                     /* INTVAL  */
  YYSYMBOL_DEALLOCATE = 7,                 /* DEALLOCATE  */
  YYSYMBOL_PARAMETERS = 8,                 /* PARAMETERS  */
  YYSYMBOL_INTERSECT = 9,                  /* INTERSECT  */
  YYSYMBOL_TEMPORARY = 10,                 /* TEMPORARY  */
  YYSYMBOL_TIMESTAMP = 11,                 /* TIMESTAMP  */
  YYSYMBOL_DISTINCT = 12,                  /* DISTINCT  */
  YYSYMBOL_NVARCHAR = 13,                  /* NVARCHAR  */
  YYSYMBOL_RESTRICT = 14,                  /* RESTRICT  */
  YYSYMBOL_TRUNCATE = 15,                  /* TRUNCATE  */
  YYSYMBOL_ANALYZE = 16,                   /* ANALYZE  */
  YYSYMBOL_BETWEEN = 17,                   /* BETWEEN  */
  YYSYMBOL_CASCADE = 18,                   /* CASCADE  */
  YYSYMBOL_COLUMNS = 19,                   /* COLUMNS  */
  YYSYMBOL_CONTROL = 20,                   /* CONTROL  */
  YYSYMBOL_DEFAULT = 21,                   /* DEFAULT  */
  YYSYMBOL_EXECUTE = 22,                   /* EXECUTE  */
  YYSYMBOL_EXPLAIN = 23,                   /* EXPLAIN  */
  YYSYMBOL_HISTORY = 24,                   /* HISTORY  */
  YYSYMBOL_INTEGER = 25,                   /* INTEGER  */
  YYSYMBOL_NATURAL = 26,                   /* NATURAL  */
  YYSYMBOL_PREPARE = 27,                   /* PREPARE  */
  YYSYMBOL_PRIMARY = 28,                   /* PRIMARY  */
  YYSYMBOL_SCHEMAS = 29,                   /* SCHEMAS  */
  YYSYMBOL_SPATIAL = 30,                   /* SPATIAL  */
  YYSYMBOL_VIRTUAL = 31,                   /* VIRTUAL  */
  YYSYMBOL_BEFORE = 32,                    /* BEFORE  */
  YYSYMBOL_COLUMN = 33,                    /* COLUMN  */
  YYSYMBOL_CREATE = 34,                    /* CREATE  */
  YYSYMBOL_DELETE = 35,                    /* DELETE  */
  YYSYMBOL_DIRECT = 36,                    /* DIRECT  */
  YYSYMBOL_DOUBLE = 37,                    /* DOUBLE  */
  YYSYMBOL_ESCAPE = 38,                    /* ESCAPE  */
  YYSYMBOL_EXCEPT = 39,                    /* EXCEPT  */
  YYSYMBOL_EXISTS = 40,                    /* EXISTS  */
  YYSYMBOL_GLOBAL = 41,                    /* GLOBAL  */
  YYSYMBOL_HAVING = 42,                    /* HAVING  */
  YYSYMBOL_IMPORT = 43,                    /* IMPORT  */
  YYSYMBOL_INSERT = 44,                    /* INSERT  */
  YYSYMBOL_ISNULL = 45,                    /* ISNULL  */
  YYSYMBOL_OFFSET = 46,                    /* OFFSET  */
  YYSYMBOL_RENAME = 47,                    /* RENAME  */
  YYSYMBOL_SCHEMA = 48,                    /* SCHEMA  */
  YYSYMBOL_SELECT = 49,                    /* SELECT  */
  YYSYMBOL_SORTED = 50,                    /* SORTED  */
  YYSYMBOL_TABLES = 51,                    /* TABLES  */
  YYSYMBOL_UNIQUE = 52,                    /* UNIQUE  */
  YYSYMBOL_UNLOAD = 53,                    /* UNLOAD  */
  YYSYMBOL_UPDATE = 54,                    /* UPDATE  */
  YYSYMBOL_VALUES = 55,                    /* VALUES  */
  YYSYMBOL_AFTER = 56,                     /* AFTER  */
  YYSYMBOL_ALTER = 57,                     /* ALTER  */
  YYSYMBOL_CROSS = 58,                     /* CROSS  */
  YYSYMBOL_DELTA = 59,                     /* DELTA  */
  YYSYMBOL_GROUP = 60,                     /* GROUP  */
  YYSYMBOL_INDEX = 61,                     /* INDEX  */
  YYSYMBOL_INNER = 62,                     /* INNER  */
  YYSYMBOL_LIMIT = 63,                     /* LIMIT  */
  YYSYMBOL_LOCAL = 64,                     /* LOCAL  */
  YYSYMBOL_MERGE = 65,                     /* MERGE  */
  YYSYMBOL_MINUS = 66,                     /* MINUS  */
  YYSYMBOL_ORDER = 67,                     /* ORDER  */
  YYSYMBOL_OUTER = 68,                     /* OUTER  */
  YYSYMBOL_RIGHT = 69,                     /* RIGHT  */
  YYSYMBOL_TABLE = 70,                     /* TABLE  */
  YYSYMBOL_UNION = 71,                     /* UNION  */
  YYSYMBOL_USING = 72,                     /* USING  */
  YYSYMBOL_WHERE = 73,                     /* WHERE  */
  YYSYMBOL_CALL = 74,                      /* CALL  */
  YYSYMBOL_CASE = 75,                      /* CASE  */
  YYSYMBOL_DATE = 76,                      /* DATE  */
  YYSYMBOL_DESC = 77,                      /* DESC  */
  YYSYMBOL_DROP = 78,                      /* DROP  */
  YYSYMBOL_ELSE = 79,                      /* ELSE  */
  YYSYMBOL_FILE = 80,                      /* FILE  */
  YYSYMBOL_FROM = 81,                      /* FROM  */
  YYSYMBOL_FULL = 82,                      /* FULL  */
  YYSYMBOL_HASH = 83,                      /* HASH  */
  YYSYMBOL_HINT = 84,                      /* HINT  */
  YYSYMBOL_INTO = 85,                      /* INTO  */
  YYSYMBOL_JOIN = 86,                      /* JOIN  */
  YYSYMBOL_LEFT = 87,                      /* LEFT  */
  YYSYMBOL_LIKE = 88,                      /* LIKE  */
  YYSYMBOL_LOAD = 89,                      /* LOAD  */
  YYSYMBOL_NULL = 90,                      /* NULL  */
  YYSYMBOL_PART = 91,                      /* PART  */
  YYSYMBOL_PLAN = 92,                      /* PLAN  */
  YYSYMBOL_SHOW = 93,                      /* SHOW  */
  YYSYMBOL_TEXT = 94,                      /* TEXT  */
  YYSYMBOL_THEN = 95,                      /* THEN  */
  YYSYMBOL_TIME = 96,                      /* TIME  */
  YYSYMBOL_VIEW = 97,                      /* VIEW  */
  YYSYMBOL_WHEN = 98,                      /* WHEN  */
  YYSYMBOL_WITH = 99,                      /* WITH  */
  YYSYMBOL_ADD = 100,                      /* ADD  */
  YYSYMBOL_ALL = 101,                      /* ALL  */
  YYSYMBOL_AND = 102,                      /* AND  */
  YYSYMBOL_ASC = 103,                      /* ASC  */
  YYSYMBOL_CSV = 104,                      /* CSV  */
  YYSYMBOL_END = 105,                      /* END  */
  YYSYMBOL_FOR = 106,                      /* FOR  */
  YYSYMBOL_INT = 107,                      /* INT  */
  YYSYMBOL_KEY = 108,                      /* KEY  */
  YYSYMBOL_NOT = 109,                      /* NOT  */
  YYSYMBOL_OFF = 110,                      /* OFF  */
  YYSYMBOL_SET = 111,                      /* SET  */
  YYSYMBOL_TBL = 112,                      /* TBL  */
  YYSYMBOL_TOP = 113,                      /* TOP  */
  YYSYMBOL_AS = 114,                       /* AS  */
  YYSYMBOL_BY = 115,                       /* BY  */
  YYSYMBOL_IF = 116,                       /* IF  */
  YYSYMBOL_IN = 117,                       /* IN  */
  YYSYMBOL_IS = 118,                       /* IS  */
  YYSYMBOL_OF = 119,                       /* OF  */
  YYSYMBOL_ON = 120,                       /* ON  */
  YYSYMBOL_OR = 121,                       /* OR  */
  YYSYMBOL_TO = 122,                       /* TO  */
  YYSYMBOL_ARRAY = 123,                    /* ARRAY  */
  YYSYMBOL_CONCAT = 124,                   /* CONCAT  */
  YYSYMBOL_ILIKE = 125,                    /* ILIKE  */
  YYSYMBOL_126_ = 126,                     /* '='  */
  YYSYMBOL_EQUALS = 127,                   /* EQUALS  */
  YYSYMBOL_NOTEQUALS = 128,                /* NOTEQUALS  */
  YYSYMBOL_129_ = 129,                     /* '<'  */
  YYSYMBOL_130_ = 130,                     /* '>'  */
  YYSYMBOL_LESS = 131,                     /* LESS  */
  YYSYMBOL_GREATER = 132,                  /* GREATER  */
  YYSYMBOL_LESSEQ = 133,                   /* LESSEQ  */
  YYSYMBOL_GREATEREQ = 134,                /* GREATEREQ  */
  YYSYMBOL_NOTNULL = 135,                  /* NOTNULL  */
  YYSYMBOL_136_ = 136,                     /* '+'  */
  YYSYMBOL_137_ = 137,                     /* '-'  */
  YYSYMBOL_138_ = 138,                     /* '*'  */
  YYSYMBOL_139_ = 139,                     /* '/'  */
  YYSYMBOL_140_ = 140,                     /* '%'  */
  YYSYMBOL_141_ = 141,                     /* '^'  */
  YYSYMBOL_UMINUS = 142,                   /* UMINUS  */
  YYSYMBOL_143_ = 143,                     /* '['  */
  YYSYMBOL_144_ = 144,                     /* ']'  */
  YYSYMBOL_145_ = 145,                     /* '('  */
  YYSYMBOL_146_ = 146,                     /* ')'  */
  YYSYMBOL_147_ = 147,                     /* '.'  */
  YYSYMBOL_148_ = 148,                     /* ';'  */
  YYSYMBOL_149_ = 149,                     /* ','  */
  YYSYMBOL_150_ = 150,                     /* '?'  */
  YYSYMBOL_YYACCEPT = 151,                 /* $accept  */
  YYSYMBOL_input = 152,                    /* input  */
  YYSYMBOL_statement_list = 153,           /* statement_list  */
  YYSYMBOL_statement = 154,                /* statement  */
  YYSYMBOL_preparable_statement = 155,     /* preparable_statement  */
  YYSYMBOL_opt_hints = 156,                /* opt_hints  */
  YYSYMBOL_hint_list = 157,                /* hint_list  */
  YYSYMBOL_hint = 158,                     /* hint  */
  YYSYMBOL_prepare_statement = 159,        /* prepare_statement  */
  YYSYMBOL_prepare_target_query = 160,     /* prepare_target_query  */
  YYSYMBOL_execute_statement = 161,        /* execute_statement  */
  YYSYMBOL_import_statement = 162,         /* import_statement  */
  YYSYMBOL_import_file_type = 163,         /* import_file_type  */
  YYSYMBOL_file_path = 164,                /* file_path  */
  YYSYMBOL_show_statement = 165,           /* show_statement  */
  YYSYMBOL_create_statement = 166,         /* create_statement  */
  YYSYMBOL_opt_not_exists = 167,           /* opt_not_exists  */
  YYSYMBOL_column_def_commalist = 168,     /* column_def_commalist  */
  YYSYMBOL_column_def = 169,               /* column_def  */
  YYSYMBOL_column_type = 170,              /* column_type  */
  YYSYMBOL_drop_statement = 171,           /* drop_statement  */
  YYSYMBOL_opt_exists = 172,               /* opt_exists  */
  YYSYMBOL_delete_statement = 173,         /* delete_statement  */
  YYSYMBOL_truncate_statement = 174,       /* truncate_statement  */
  YYSYMBOL_insert_statement = 175,         /* insert_statement  */
  YYSYMBOL_opt_column_list = 176,          /* opt_column_list  */
  YYSYMBOL_update_statement = 177,         /* update_statement  */
  YYSYMBOL_update_clause_commalist = 178,  /* update_clause_commalist  */
  YYSYMBOL_update_clause = 179,            /* update_clause  */
  YYSYMBOL_select_statement = 180,         /* select_statement  */
  YYSYMBOL_select_with_paren = 181,        /* select_with_paren  */
  YYSYMBOL_select_paren_or_clause = 182,   /* select_paren_or_clause  */
  YYSYMBOL_select_no_paren = 183,          /* select_no_paren  */
  YYSYMBOL_set_operator = 184,             /* set_operator  */
  YYSYMBOL_set_type = 185,                 /* set_type  */
  YYSYMBOL_opt_all = 186,                  /* opt_all  */
  YYSYMBOL_select_clause = 187,            /* select_clause  */
  YYSYMBOL_opt_distinct = 188,             /* opt_distinct  */
  YYSYMBOL_select_list = 189,              /* select_list  */
  YYSYMBOL_from_clause = 190,              /* from_clause  */
  YYSYMBOL_opt_where = 191,                /* opt_where  */
  YYSYMBOL_opt_group = 192,                /* opt_group  */
  YYSYMBOL_opt_having = 193,               /* opt_having  */
  YYSYMBOL_opt_order = 194,                /* opt_order  */
  YYSYMBOL_order_list = 195,               /* order_list  */
  YYSYMBOL_order_desc = 196,               /* order_desc  */
  YYSYMBOL_opt_order_type = 197,           /* opt_order_type  */
  YYSYMBOL_opt_top = 198,                  /* opt_top  */
  YYSYMBOL_opt_limit = 199,                /* opt_limit  */
  YYSYMBOL_expr_list = 200,                /* expr_list  */
  YYSYMBOL_literal_list = 201,             /* literal_list  */
  YYSYMBOL_expr_alias = 202,               /* expr_alias  */
  YYSYMBOL_expr = 203,                     /* expr  */
  YYSYMBOL_operand = 204,                  /* operand  */
  YYSYMBOL_scalar_expr = 205,              /* scalar_expr  */
  YYSYMBOL_unary_expr = 206,               /* unary_expr  */
  YYSYMBOL_binary_expr = 207,              /* binary_expr  */
  YYSYMBOL_logic_expr = 208,               /* logic_expr  */
  YYSYMBOL_in_expr = 209,                  /* in_expr  */
  YYSYMBOL_case_expr = 210,                /* case_expr  */
  YYSYMBOL_case_list = 211,                /* case_list  */
  YYSYMBOL_exists_expr = 212,              /* exists_expr  */
  YYSYMBOL_comp_expr = 213,                /* comp_expr  */
  YYSYMBOL_function_expr = 214,            /* function_expr  */
  YYSYMBOL_array_expr = 215,               /* array_expr  */
  YYSYMBOL_array_index = 216,              /* array_index  */
  YYSYMBOL_between_expr = 217,             /* between_expr  */
  YYSYMBOL_column_name = 218,              /* column_name  */
  YYSYMBOL_literal = 219,                  /* literal  */
  YYSYMBOL_string_literal = 220,           /* string_literal  */
  YYSYMBOL_num_literal = 221,              /* num_literal  */
  YYSYMBOL_int_literal = 222,              /* int_literal  */
  YYSYMBOL_null_literal = 223,             /* null_literal  */
  YYSYMBOL_param_expr = 224,               /* param_expr  */
  YYSYMBOL_table_ref = 225,                /* table_ref  */
  YYSYMBOL_table_ref_atomic = 226,         /* table_ref_atomic  */
  YYSYMBOL_nonjoin_table_ref_atomic = 227, /* nonjoin_table_ref_atomic  */
  YYSYMBOL_table_ref_commalist = 228,      /* table_ref_commalist  */
  YYSYMBOL_table_ref_name = 229,           /* table_ref_name  */
  YYSYMBOL_table_ref_name_no_alias = 230,  /* table_ref_name_no_alias  */
  YYSYMBOL_table_name = 231,               /* table_name  */
  YYSYMBOL_alias = 232,                    /* alias  */
  YYSYMBOL_opt_alias = 233,                /* opt_alias  */
  YYSYMBOL_join_clause = 234,              /* join_clause  */
  YYSYMBOL_opt_join_type = 235,            /* opt_join_type  */
  YYSYMBOL_join_condition = 236,           /* join_condition  */
  YYSYMBOL_opt_semicolon = 237,            /* opt_semicolon  */
  YYSYMBOL_ident_commalist = 238           /* ident_commalist  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined HSQL_LTYPE_IS_TRIVIAL && HSQL_LTYPE_IS_TRIVIAL \
             && defined HSQL_STYPE_IS_TRIVIAL && HSQL_STYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  52
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   593

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  151
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  88
/* YYNRULES -- Number of rules.  */
#define YYNRULES  208
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  384

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   388


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,   140,     2,     2,
     145,   146,   138,   136,   149,   137,   147,   139,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,   148,
     129,   126,   130,   150,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   143,     2,   144,   141,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   127,   128,   131,   132,   133,   134,   135,   142
};

#if HSQL_DEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   251,   251,   278,   284,   293,   297,   301,   308,   309,
     310,   311,   312,   313,   314,   315,   316,   325,   326,   331,
     332,   336,   340,   352,   359,   362,   366,   378,   387,   391,
     401,   404,   418,   425,   432,   443,   444,   448,   449,   453,
     460,   461,   462,   463,   473,   479,   485,   493,   494,   503,
     512,   525,   532,   543,   544,   554,   563,   564,   568,   580,
     581,   582,   599,   600,   604,   605,   609,   619,   636,   640,
     641,   642,   646,   647,   651,   663,   664,   668,   672,   677,
     678,   682,   687,   691,   692,   695,   696,   700,   701,   705,
     709,   710,   711,   717,   718,   722,   723,   724,   731,   732,
     736,   737,   741,   748,   749,   750,   751,   752,   756,   757,
     758,   759,   760,   761,   762,   763,   764,   768,   769,   773,
     774,   775,   776,   777,   781,   782,   783,   784,   785,   786,
     787,   788,   789,   790,   791,   795,   796,   800,   801,   802,
     803,   809,   810,   811,   812,   816,   817,   821,   822,   826,
     827,   828,   829,   830,   831,   832,   836,   837,   841,   845,
     849,   853,   854,   855,   856,   860,   861,   862,   863,   867,
     872,   873,   877,   881,   885,   897,   898,   908,   909,   913,
     914,   923,   924,   929,   940,   949,   950,   955,   956,   960,
     961,   969,   977,   987,  1006,  1007,  1008,  1009,  1010,  1011,
    1012,  1013,  1014,  1015,  1020,  1029,  1030,  1035,  1036
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "IDENTIFIER", "STRING",
  "FLOATVAL", "INTVAL", "DEALLOCATE", "PARAMETERS", "INTERSECT",
  "TEMPORARY", "TIMESTAMP", "DISTINCT", "NVARCHAR", "RESTRICT", "TRUNCATE",
  "ANALYZE", "BETWEEN", "CASCADE", "COLUMNS", "CONTROL", "DEFAULT",
  "EXECUTE", "EXPLAIN", "HISTORY", "INTEGER", "NATURAL", "PREPARE",
  "PRIMARY", "SCHEMAS", "SPATIAL", "VIRTUAL", "BEFORE", "COLUMN", "CREATE",
  "DELETE", "DIRECT", "DOUBLE", "ESCAPE", "EXCEPT", "EXISTS", "GLOBAL",
  "HAVING", "IMPORT", "INSERT", "ISNULL", "OFFSET", "RENAME", "SCHEMA",
  "SELECT", "SORTED", "TABLES", "UNIQUE", "UNLOAD", "UPDATE", "VALUES",
  "AFTER", "ALTER", "CROSS", "DELTA", "GROUP", "INDEX", "INNER", "LIMIT",
  "LOCAL", "MERGE", "MINUS", "ORDER", "OUTER", "RIGHT", "TABLE", "UNION",
  "USING", "WHERE", "CALL", "CASE", "DATE", "DESC", "DROP", "ELSE", "FILE",
  "FROM", "FULL", "HASH", "HINT", "INTO", "JOIN", "LEFT", "LIKE", "LOAD",
  "NULL", "PART", "PLAN", "SHOW", "TEXT", "THEN", "TIME", "VIEW", "WHEN",
  "WITH", "ADD", "ALL", "AND", "ASC", "CSV", "END", "FOR", "INT", "KEY",
  "NOT", "OFF", "SET", "TBL", "TOP", "AS", "BY", "IF", "IN", "IS", "OF",
  "ON", "OR", "TO", "ARRAY", "CONCAT", "ILIKE", "'='", "EQUALS",
  "NOTEQUALS", "'<'", "'>'", "LESS", "GREATER", "LESSEQ", "GREATEREQ",
  "NOTNULL", "'+'", "'-'", "'*'", "'/'", "'%'", "'^'", "UMINUS", "'['",
  "']'", "'('", "')'", "'.'", "';'", "','", "'?'", "$accept", "input",
  "statement_list", "statement", "preparable_statement", "opt_hints",
  "hint_list", "hint", "prepare_statement", "prepare_target_query",
  "execute_statement", "import_statement", "import_file_type", "file_path",
  "show_statement", "create_statement", "opt_not_exists",
  "column_def_commalist", "column_def", "column_type", "drop_statement",
  "opt_exists", "delete_statement", "truncate_statement",
  "insert_statement", "opt_column_list", "update_statement",
  "update_clause_commalist", "update_clause", "select_statement",
  "select_with_paren", "select_paren_or_clause", "select_no_paren",
  "set_operator", "set_type", "opt_all", "select_clause", "opt_distinct",
  "select_list", "from_clause", "opt_where", "opt_group", "opt_having",
  "opt_order", "order_list", "order_desc", "opt_order_type", "opt_top",
  "opt_limit", "expr_list", "literal_list", "expr_alias", "expr",
  "operand", "scalar_expr", "unary_expr", "binary_expr", "logic_expr",
  "in_expr", "case_expr", "case_list", "exists_expr", "comp_expr",
  "function_expr", "array_expr", "array_index", "between_expr",
  "column_name", "literal", "string_literal", "num_literal", "int_literal",
  "null_literal", "param_expr", "table_ref", "table_ref_atomic",
  "nonjoin_table_ref_atomic", "table_ref_commalist", "table_ref_name",
  "table_ref_name_no_alias", "table_name", "alias", "opt_alias",
  "join_clause", "opt_join_type", "join_condition", "opt_semicolon",
  "ident_commalist", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-288)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-204)

#define yytable_value_is_error(Yyn) \
  ((Yyn) == YYTABLE_NINF)

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     234,    17,    30,    45,   149,   -35,   -10,    24,    84,    80,
      30,   -31,     8,   -36,   179,    50,  -288,   103,   103,  -288,
    -288,  -288,  -288,  -288,  -288,  -288,  -288,  -288,  -288,    22,
    -288,    21,   204,    61,  -288,    73,   142,   109,   109,    30,
     133,    30,   246,   245,   147,  -288,   148,   148,    30,  -288,
     119,   128,  -288,   234,  -288,   205,  -288,  -288,  -288,  -288,
    -288,   -36,   190,   180,   -36,   231,  -288,   293,    11,   294,
     188,    30,    30,   227,  -288,   219,   157,  -288,  -288,  -288,
     200,   300,   264,    30,    30,  -288,  -288,  -288,  -288,   162,
    -288,   241,  -288,  -288,  -288,   200,   241,   246,  -288,  -288,
    -288,  -288,  -288,  -288,   -27,  -288,  -288,  -288,  -288,  -288,
    -288,  -288,  -288,   274,   -58,   157,   200,  -288,   311,   314,
      -2,    99,   173,    72,   226,   176,   230,  -288,    76,   240,
     175,  -288,     6,   268,  -288,  -288,  -288,  -288,  -288,  -288,
    -288,  -288,  -288,  -288,  -288,  -288,  -288,  -288,   199,   -59,
    -288,  -288,  -288,  -288,   323,   231,   181,  -288,   -51,   231,
     282,  -288,    11,  -288,   217,   328,   218,    -8,   248,  -288,
    -288,    66,   191,  -288,    12,    15,   291,   200,   -53,   -33,
     196,   230,   327,   200,    49,   197,   -83,     3,   227,   200,
    -288,   200,   339,   200,  -288,  -288,   230,  -288,   230,   -60,
     202,    20,   230,   230,   230,   230,   230,   230,   230,   230,
     230,   230,   230,   230,   230,   230,   230,   246,   200,   300,
    -288,   203,    78,  -288,  -288,   200,  -288,  -288,  -288,  -288,
     246,  -288,   271,    -5,    96,  -288,   -36,    30,  -288,   341,
      11,  -288,   200,  -288,  -288,   206,    28,    16,   200,   200,
    -288,   291,   266,    23,  -288,  -288,   -36,  -288,   185,  -288,
     208,  -288,     4,  -288,   295,  -288,  -288,  -288,   256,   301,
     355,   230,   214,    76,  -288,   270,   222,   355,   355,   355,
     355,   379,   379,   379,   379,    49,    49,    41,    41,    41,
      51,   225,    -8,  -288,    11,  -288,   323,  -288,  -288,   311,
    -288,  -288,  -288,  -288,  -288,  -288,   328,  -288,  -288,  -288,
     102,   113,  -288,   200,   200,  -288,    75,    55,   215,  -288,
     216,   280,  -288,  -288,  -288,   302,   306,   310,   296,     3,
    -288,   269,  -288,   230,   355,    76,   235,   124,  -288,  -288,
     130,  -288,  -288,  -288,  -288,  -288,    -8,    95,  -288,   200,
    -288,     4,     3,  -288,  -288,  -288,     3,   224,   200,   327,
     237,   138,  -288,  -288,  -288,  -288,    -8,  -288,  -288,   473,
     -32,  -288,  -288,   242,   200,   200,  -288,    18,    -8,  -288,
      -8,   243,   253,  -288
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,    94,
       0,     0,     0,     0,     0,   206,     3,    18,    18,    16,
       9,     7,    10,    15,    12,    13,    11,    14,     8,    59,
      60,    86,     0,   185,    50,    25,     0,    36,    36,     0,
       0,     0,     0,    76,     0,   184,    48,    48,     0,    30,
       0,     0,     1,   205,     2,     0,     6,     5,    70,    71,
      69,     0,    73,     0,     0,    97,    46,     0,     0,     0,
       0,     0,     0,    80,    28,     0,    54,   172,    93,    75,
       0,     0,     0,     0,     0,    31,    63,    62,     4,     0,
      64,    86,    65,    72,    68,     0,    86,     0,    66,   186,
     169,   170,   173,   174,     0,   100,   165,   166,   171,   167,
     168,    24,    23,     0,     0,    54,     0,    49,     0,     0,
       0,   161,     0,     0,     0,     0,     0,   163,     0,     0,
      77,    98,   190,   103,   110,   111,   112,   105,   107,   113,
     106,   124,   114,   115,   109,   104,   117,   118,     0,    80,
      56,    47,    44,    45,     0,    97,    85,    87,    92,    97,
      95,    26,     0,    35,     0,     0,     0,    79,     0,    29,
     207,     0,     0,    52,    76,     0,     0,     0,     0,     0,
       0,     0,   120,     0,   119,     0,     0,     0,    80,     0,
     188,     0,     0,     0,   189,   102,     0,   121,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      55,    21,     0,    19,    61,     0,    91,    90,    89,    67,
       0,   101,     0,     0,     0,    37,     0,     0,    53,     0,
       0,   156,     0,   162,   164,     0,     0,     0,     0,     0,
     143,     0,     0,     0,   116,   108,     0,    78,   175,   177,
       0,   179,   190,   178,    82,    99,   135,   187,   136,     0,
     131,     0,     0,     0,   122,     0,   134,   133,   149,   150,
     151,   152,   153,   154,   155,   126,   125,   128,   127,   129,
     130,     0,    58,    57,     0,    17,     0,    88,    96,     0,
      41,    42,    43,    40,    39,    33,     0,    34,    27,   208,
       0,     0,   147,     0,     0,   141,     0,     0,     0,   158,
       0,     0,   202,   194,   200,   198,   201,   196,     0,     0,
     183,     0,    74,     0,   132,     0,     0,     0,   123,   159,
       0,    20,    32,    38,    51,   157,   145,     0,   144,     0,
     148,   190,     0,   197,   199,   195,     0,   176,     0,   160,
       0,     0,   139,   137,    22,   142,   146,   180,   191,   203,
      84,   140,   138,     0,     0,     0,    81,     0,   204,   192,
      83,   161,     0,   193
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -288,  -288,  -288,   335,  -288,   373,  -288,   116,  -288,  -288,
    -288,  -288,  -288,   114,  -288,  -288,   376,  -288,   110,  -288,
    -288,   370,  -288,  -288,  -288,   303,  -288,  -288,   201,  -152,
      42,   357,   -13,   391,  -288,  -288,   107,   249,  -288,  -288,
    -124,  -288,  -288,    68,  -288,   207,  -288,  -288,  -119,  -175,
    -203,   244,   -94,   -70,  -288,  -288,  -288,  -288,  -288,  -288,
     272,  -288,  -288,  -288,  -288,  -288,  -288,    69,   -66,  -113,
    -288,   -39,  -288,  -288,  -288,  -287,    97,  -288,  -288,  -288,
       2,  -288,  -251,  -288,  -288,  -288,  -288,  -288
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    14,    15,    16,    17,    56,   222,   223,    18,   112,
      19,    20,    75,   168,    21,    22,    71,   234,   235,   304,
      23,    83,    24,    25,    26,   120,    27,   149,   150,    28,
      29,    91,    30,    61,    62,    94,    31,    80,   129,   188,
     117,   332,   376,    65,   156,   157,   228,    43,    98,   130,
     104,   131,   132,   133,   134,   135,   136,   137,   138,   139,
     179,   140,   141,   142,   143,   144,   145,   146,   147,   106,
     107,   108,   109,   110,   257,   258,   259,   260,   261,    44,
     262,   194,   195,   263,   328,   379,    54,   171
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      51,   158,   105,    78,    34,   169,    33,   190,   253,   190,
     375,   330,    45,     9,   116,   100,   101,    77,   243,   191,
     300,   381,   167,   164,    79,   220,   226,    48,   271,   178,
      58,    58,   301,    33,   186,    37,   224,   310,   193,    46,
     229,    73,   357,    76,    32,   177,   248,     9,    35,   191,
      85,   191,   227,   172,   182,    50,   184,   272,   160,    49,
      59,    59,    38,   255,   264,   249,    47,   311,   193,   369,
     193,    39,   250,   114,   115,   121,   100,   101,    77,   121,
     100,   101,    77,   246,   307,   152,   153,   165,    63,   302,
     219,   340,    60,    60,   191,   314,   231,   266,   337,   268,
     367,   102,   303,    90,   320,    40,    90,   173,   191,    13,
     274,   182,   122,   193,   249,   185,   122,   189,   192,   161,
     192,   315,   162,   313,   292,     9,   269,   193,   270,   275,
     191,   158,   276,   277,   278,   279,   280,   281,   282,   283,
     284,   285,   286,   287,   288,   289,   290,   123,   256,   193,
     349,   123,    36,   244,   316,   317,   127,   191,   241,   155,
     361,   103,   102,   245,   159,   202,   102,   319,    92,    41,
     177,    92,   189,   202,   105,   202,   193,   191,   291,    52,
     348,   124,   216,   370,   217,   124,   169,   213,   214,   215,
     216,   298,   217,    42,   217,   125,   193,   191,    53,   125,
     365,   334,    55,   121,   100,   101,    77,    66,    67,   126,
     127,   321,   238,   126,   127,   239,   193,   128,    68,   346,
     347,   128,   103,    69,   295,    70,   103,   296,   105,   121,
     100,   101,    77,   121,   100,   101,    77,    74,   318,   308,
     122,     1,   305,   322,   174,   306,   175,   323,   344,     2,
     321,   162,    77,   324,   325,   366,     3,    79,    81,   345,
     336,     4,   189,   359,    82,    86,   180,   326,     5,     6,
     363,  -203,   327,   189,    87,   123,   364,     7,     8,   162,
     378,   380,   322,     9,   372,   196,   323,   189,    10,    89,
     102,    93,   324,   325,    97,    95,    99,   113,   111,   118,
     116,   123,   119,   148,   151,   123,   326,   154,    63,   124,
    -203,   327,    11,   197,   163,   100,   102,   170,   176,   183,
     102,   187,   360,   125,   189,   218,   221,    12,   230,   232,
     225,   233,   236,   237,  -181,   181,   240,   126,   127,   181,
       9,   251,   267,   254,   309,   128,   197,   273,   294,   125,
     103,   299,   312,   125,   271,   331,   198,   329,   191,   335,
     338,   350,   351,   126,   127,   217,   352,   126,   127,   339,
     353,   128,   197,  -182,   354,   128,   103,   199,   355,    13,
     103,   362,   356,   371,   358,   200,   201,   377,    88,   198,
     175,    57,   202,   203,   204,   205,   206,   207,   208,   383,
     197,   209,   210,   333,   211,   212,   213,   214,   215,   216,
     252,   217,   341,   342,    72,   198,   343,    84,   166,   201,
     293,    96,    64,   242,   197,   202,   203,   204,   205,   206,
     207,   208,   297,   265,   209,   210,   252,   211,   212,   213,
     214,   215,   216,  -204,   217,   201,   382,     0,     0,   368,
     247,   202,   203,   204,   205,   206,   207,   208,     0,     0,
     209,   210,     0,   211,   212,   213,   214,   215,   216,     0,
     217,     0,     0,   201,     0,     0,     0,     0,     0,   202,
    -204,  -204,  -204,  -204,   207,   208,     0,     0,   209,   210,
       0,   211,   212,   213,   214,   215,   216,   201,   217,   321,
       0,     0,     0,   202,     0,     0,     0,     0,  -204,  -204,
       0,     0,  -204,  -204,     0,   211,   212,   213,   214,   215,
     216,     0,   217,     0,     0,     0,     0,     0,     0,     0,
       0,   322,     0,     0,     0,   323,     0,     0,     0,     0,
       0,   324,   325,     0,     0,   373,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   326,     0,     0,     0,     0,
     327,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   374
};

static const yytype_int16 yycheck[] =
{
      13,    95,    68,    42,     2,   118,     3,     3,   183,     3,
      42,   262,    10,    49,    73,     4,     5,     6,     3,   102,
      25,     3,   116,    81,    12,   149,    77,    19,    88,   123,
       9,     9,    37,     3,   128,    70,   155,   240,   121,    70,
     159,    39,   329,    41,    27,    98,    79,    49,     3,   102,
      48,   102,   103,    55,   124,    13,   126,   117,    97,    51,
      39,    39,    97,   146,   188,    98,    97,   242,   121,   356,
     121,    81,   105,    71,    72,     3,     4,     5,     6,     3,
       4,     5,     6,   177,   236,    83,    84,   145,    67,    94,
     149,   294,    71,    71,   102,    79,   162,   191,   273,   193,
     351,    90,   107,    61,   256,    81,    64,   120,   102,   145,
      90,   181,    40,   121,    98,   128,    40,   149,   114,   146,
     114,   105,   149,    95,   218,    49,   196,   121,   198,   109,
     102,   225,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   211,   212,   213,   214,   215,   216,    75,   145,   121,
      95,    75,     3,   138,   248,   249,   138,   102,   146,    91,
     335,   150,    90,   176,    96,   124,    90,   144,    61,    85,
      98,    64,   149,   124,   240,   124,   121,   102,   217,     0,
     105,   109,   141,   358,   143,   109,   299,   138,   139,   140,
     141,   230,   143,   113,   143,   123,   121,   102,   148,   123,
     105,   271,    99,     3,     4,     5,     6,     3,   147,   137,
     138,    26,   146,   137,   138,   149,   121,   145,   145,   313,
     314,   145,   150,    81,   146,   116,   150,   149,   294,     3,
       4,     5,     6,     3,     4,     5,     6,   104,   251,   237,
      40,     7,   146,    58,   145,   149,   147,    62,   146,    15,
      26,   149,     6,    68,    69,   349,    22,    12,   111,   146,
     273,    27,   149,   333,   116,   146,    40,    82,    34,    35,
     146,    86,    87,   149,   146,    75,   146,    43,    44,   149,
     374,   375,    58,    49,   146,    17,    62,   149,    54,    84,
      90,   101,    68,    69,    63,   115,     3,   109,     4,    80,
      73,    75,   145,     3,    40,    75,    82,   145,    67,   109,
      86,    87,    78,    45,    40,     4,    90,     3,   145,   143,
      90,    81,   335,   123,   149,   126,     3,    93,    46,   112,
     149,     3,   114,    85,   149,   109,   145,   137,   138,   109,
      49,   145,     3,   146,     3,   145,    45,   145,   145,   123,
     150,    80,   146,   123,    88,    60,    88,   149,   102,   145,
      90,   146,   146,   137,   138,   143,    86,   137,   138,   144,
      68,   145,    45,   149,    68,   145,   150,   109,    68,   145,
     150,   146,    86,   146,   115,   117,   118,   145,    53,    88,
     147,    18,   124,   125,   126,   127,   128,   129,   130,   146,
      45,   133,   134,   102,   136,   137,   138,   139,   140,   141,
     109,   143,   296,   299,    38,    88,   306,    47,   115,   118,
     219,    64,    31,   174,    45,   124,   125,   126,   127,   128,
     129,   130,   225,   189,   133,   134,   109,   136,   137,   138,
     139,   140,   141,    88,   143,   118,   377,    -1,    -1,   352,
     178,   124,   125,   126,   127,   128,   129,   130,    -1,    -1,
     133,   134,    -1,   136,   137,   138,   139,   140,   141,    -1,
     143,    -1,    -1,   118,    -1,    -1,    -1,    -1,    -1,   124,
     125,   126,   127,   128,   129,   130,    -1,    -1,   133,   134,
      -1,   136,   137,   138,   139,   140,   141,   118,   143,    26,
      -1,    -1,    -1,   124,    -1,    -1,    -1,    -1,   129,   130,
      -1,    -1,   133,   134,    -1,   136,   137,   138,   139,   140,
     141,    -1,   143,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    58,    -1,    -1,    -1,    62,    -1,    -1,    -1,    -1,
      -1,    68,    69,    -1,    -1,    72,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    82,    -1,    -1,    -1,    -1,
      87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   120
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     7,    15,    22,    27,    34,    35,    43,    44,    49,
      54,    78,    93,   145,   152,   153,   154,   155,   159,   161,
     162,   165,   166,   171,   173,   174,   175,   177,   180,   181,
     183,   187,    27,     3,   231,     3,     3,    70,    97,    81,
      81,    85,   113,   198,   230,   231,    70,    97,    19,    51,
     181,   183,     0,   148,   237,    99,   156,   156,     9,    39,
      71,   184,   185,    67,   184,   194,     3,   147,   145,    81,
     116,   167,   167,   231,   104,   163,   231,     6,   222,    12,
     188,   111,   116,   172,   172,   231,   146,   146,   154,    84,
     181,   182,   187,   101,   186,   115,   182,    63,   199,     3,
       4,     5,    90,   150,   201,   219,   220,   221,   222,   223,
     224,     4,   160,   109,   231,   231,    73,   191,    80,   145,
     176,     3,    40,    75,   109,   123,   137,   138,   145,   189,
     200,   202,   203,   204,   205,   206,   207,   208,   209,   210,
     212,   213,   214,   215,   216,   217,   218,   219,     3,   178,
     179,    40,   231,   231,   145,   194,   195,   196,   203,   194,
     222,   146,   149,    40,    81,   145,   176,   203,   164,   220,
       3,   238,    55,   183,   145,   147,   145,    98,   203,   211,
      40,   109,   204,   143,   204,   183,   203,    81,   190,   149,
       3,   102,   114,   121,   232,   233,    17,    45,    88,   109,
     117,   118,   124,   125,   126,   127,   128,   129,   130,   133,
     134,   136,   137,   138,   139,   140,   141,   143,   126,   149,
     191,     3,   157,   158,   199,   149,    77,   103,   197,   199,
      46,   219,   112,     3,   168,   169,   114,    85,   146,   149,
     145,   146,   188,     3,   138,   183,   203,   211,    79,    98,
     105,   145,   109,   200,   146,   146,   145,   225,   226,   227,
     228,   229,   231,   234,   191,   202,   203,     3,   203,   204,
     204,    88,   117,   145,    90,   109,   204,   204,   204,   204,
     204,   204,   204,   204,   204,   204,   204,   204,   204,   204,
     204,   222,   203,   179,   145,   146,   149,   196,   222,    80,
      25,    37,    94,   107,   170,   146,   149,   180,   231,     3,
     201,   200,   146,    95,    79,   105,   203,   203,   183,   144,
     180,    26,    58,    62,    68,    69,    82,    87,   235,   149,
     233,    60,   192,   102,   204,   145,   183,   200,    90,   144,
     201,   158,   164,   169,   146,   146,   203,   203,   105,    95,
     146,   146,    86,    68,    68,    68,    86,   226,   115,   204,
     183,   200,   146,   146,   146,   105,   203,   233,   227,   226,
     200,   146,   146,    72,   120,    42,   193,   145,   203,   236,
     203,     3,   218,   146
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,   151,   152,   153,   153,   154,   154,   154,   155,   155,
     155,   155,   155,   155,   155,   155,   155,   156,   156,   157,
     157,   158,   158,   159,   160,   161,   161,   162,   163,   164,
     165,   165,   166,   166,   166,   167,   167,   168,   168,   169,
     170,   170,   170,   170,   171,   171,   171,   172,   172,   173,
     174,   175,   175,   176,   176,   177,   178,   178,   179,   180,
     180,   180,   181,   181,   182,   182,   183,   183,   184,   185,
     185,   185,   186,   186,   187,   188,   188,   189,   190,   191,
     191,   192,   192,   193,   193,   194,   194,   195,   195,   196,
     197,   197,   197,   198,   198,   199,   199,   199,   200,   200,
     201,   201,   202,   203,   203,   203,   203,   203,   204,   204,
     204,   204,   204,   204,   204,   204,   204,   205,   205,   206,
     206,   206,   206,   206,   207,   207,   207,   207,   207,   207,
     207,   207,   207,   207,   207,   208,   208,   209,   209,   209,
     209,   210,   210,   210,   210,   211,   211,   212,   212,   213,
     213,   213,   213,   213,   213,   213,   214,   214,   215,   216,
     217,   218,   218,   218,   218,   219,   219,   219,   219,   220,
     221,   221,   222,   223,   224,   225,   225,   226,   226,   227,
     227,   228,   228,   229,   230,   231,   231,   232,   232,   233,
     233,   234,   234,   234,   235,   235,   235,   235,   235,   235,
     235,   235,   235,   235,   236,   237,   237,   238,   238
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     1,     3,     2,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     5,     0,     1,
       3,     1,     4,     4,     1,     2,     5,     7,     1,     1,
       2,     3,     8,     7,     7,     3,     0,     1,     3,     2,
       1,     1,     1,     1,     4,     4,     3,     2,     0,     4,
       2,     8,     5,     3,     0,     5,     1,     3,     3,     1,
       1,     5,     3,     3,     1,     1,     3,     5,     2,     1,
       1,     1,     1,     0,     7,     1,     0,     1,     2,     2,
       0,     4,     0,     2,     0,     3,     0,     1,     3,     2,
       1,     1,     0,     2,     0,     2,     4,     0,     1,     3,
       1,     3,     2,     1,     1,     1,     1,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     3,     1,     1,     2,
       2,     2,     3,     4,     1,     3,     3,     3,     3,     3,
       3,     3,     4,     3,     3,     3,     3,     5,     6,     5,
       6,     4,     6,     3,     5,     4,     5,     4,     5,     3,
       3,     3,     3,     3,     3,     3,     3,     5,     4,     4,
       5,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     1,     1,     1,
       4,     1,     3,     2,     1,     1,     3,     2,     1,     1,
       0,     4,     6,     8,     1,     2,     1,     2,     1,     2,
       1,     1,     1,     0,     1,     1,     0,     1,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = SQL_HSQL_EMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == SQL_HSQL_EMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, result, scanner, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use SQL_HSQL_error or SQL_HSQL_UNDEF. */
#define YYERRCODE SQL_HSQL_UNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if HSQL_DEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined HSQL_LTYPE_IS_TRIVIAL && HSQL_LTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, result, scanner); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, hsql::SQLParserResult* result, yyscan_t scanner)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (result);
  YY_USE (scanner);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, hsql::SQLParserResult* result, yyscan_t scanner)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, result, scanner);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, hsql::SQLParserResult* result, yyscan_t scanner)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), result, scanner);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, result, scanner); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !HSQL_DEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !HSQL_DEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, hsql::SQLParserResult* result, yyscan_t scanner)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (result);
  YY_USE (scanner);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_IDENTIFIER: /* IDENTIFIER  */
            { free( (((*yyvaluep).sval)) ); }
        break;

    case YYSYMBOL_STRING: /* STRING  */
            { free( (((*yyvaluep).sval)) ); }
        break;

    case YYSYMBOL_FLOATVAL: /* FLOATVAL  */
            { }
        break;

    case YYSYMBOL_INTVAL: /* INTVAL  */
            { }
        break;

    case YYSYMBOL_statement_list: /* statement_list  */
            {
	if ((((*yyvaluep).stmt_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).stmt_vec))->size(); ++var) {
				delete (((*yyvaluep).stmt_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).stmt_vec));
}
        break;

    case YYSYMBOL_statement: /* statement  */
            { delete (((*yyvaluep).statement)); }
        break;

    case YYSYMBOL_preparable_statement: /* preparable_statement  */
            { delete (((*yyvaluep).statement)); }
        break;

    case YYSYMBOL_opt_hints: /* opt_hints  */
            {
	if ((((*yyvaluep).expr_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).expr_vec))->size(); ++var) {
				delete (((*yyvaluep).expr_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).expr_vec));
}
        break;

    case YYSYMBOL_hint_list: /* hint_list  */
            {
	if ((((*yyvaluep).expr_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).expr_vec))->size(); ++var) {
				delete (((*yyvaluep).expr_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).expr_vec));
}
        break;

    case YYSYMBOL_hint: /* hint  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_prepare_statement: /* prepare_statement  */
            { delete (((*yyvaluep).prep_stmt)); }
        break;

    case YYSYMBOL_prepare_target_query: /* prepare_target_query  */
            { free( (((*yyvaluep).sval)) ); }
        break;

    case YYSYMBOL_execute_statement: /* execute_statement  */
            { delete (((*yyvaluep).exec_stmt)); }
        break;

    case YYSYMBOL_import_statement: /* import_statement  */
            { delete (((*yyvaluep).import_stmt)); }
        break;

    case YYSYMBOL_import_file_type: /* import_file_type  */
            { }
        break;

    case YYSYMBOL_file_path: /* file_path  */
            { free( (((*yyvaluep).sval)) ); }
        break;

    case YYSYMBOL_show_statement: /* show_statement  */
            { delete (((*yyvaluep).show_stmt)); }
        break;

    case YYSYMBOL_create_statement: /* create_statement  */
            { delete (((*yyvaluep).create_stmt)); }
        break;

    case YYSYMBOL_opt_not_exists: /* opt_not_exists  */
            { }
        break;

    case YYSYMBOL_column_def_commalist: /* column_def_commalist  */
            {
	if ((((*yyvaluep).column_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).column_vec))->size(); ++var) {
				delete (((*yyvaluep).column_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).column_vec));
}
        break;

    case YYSYMBOL_column_def: /* column_def  */
            { delete (((*yyvaluep).column_t)); }
        break;

    case YYSYMBOL_column_type: /* column_type  */
            { }
        break;

    case YYSYMBOL_drop_statement: /* drop_statement  */
            { delete (((*yyvaluep).drop_stmt)); }
        break;

    case YYSYMBOL_opt_exists: /* opt_exists  */
            { }
        break;

    case YYSYMBOL_delete_statement: /* delete_statement  */
            { delete (((*yyvaluep).delete_stmt)); }
        break;

    case YYSYMBOL_truncate_statement: /* truncate_statement  */
            { delete (((*yyvaluep).delete_stmt)); }
        break;

    case YYSYMBOL_insert_statement: /* insert_statement  */
            { delete (((*yyvaluep).insert_stmt)); }
        break;

    case YYSYMBOL_opt_column_list: /* opt_column_list  */
            {
	if ((((*yyvaluep).str_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).str_vec))->size(); ++var) {
				delete (((*yyvaluep).str_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).str_vec));
}
        break;

    case YYSYMBOL_update_statement: /* update_statement  */
            { delete (((*yyvaluep).update_stmt)); }
        break;

    case YYSYMBOL_update_clause_commalist: /* update_clause_commalist  */
            {
	if ((((*yyvaluep).update_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).update_vec))->size(); ++var) {
				delete (((*yyvaluep).update_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).update_vec));
}
        break;

    case YYSYMBOL_update_clause: /* update_clause  */
            { delete (((*yyvaluep).update_t)); }
        break;

    case YYSYMBOL_select_statement: /* select_statement  */
            { delete (((*yyvaluep).select_stmt)); }
        break;

    case YYSYMBOL_select_with_paren: /* select_with_paren  */
            { delete (((*yyvaluep).select_stmt)); }
        break;

    case YYSYMBOL_select_paren_or_clause: /* select_paren_or_clause  */
            { delete (((*yyvaluep).select_stmt)); }
        break;

    case YYSYMBOL_select_no_paren: /* select_no_paren  */
            { delete (((*yyvaluep).select_stmt)); }
        break;

    case YYSYMBOL_select_clause: /* select_clause  */
            { delete (((*yyvaluep).select_stmt)); }
        break;

    case YYSYMBOL_opt_distinct: /* opt_distinct  */
            { }
        break;

    case YYSYMBOL_select_list: /* select_list  */
            {
	if ((((*yyvaluep).expr_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).expr_vec))->size(); ++var) {
				delete (((*yyvaluep).expr_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).expr_vec));
}
        break;

    case YYSYMBOL_from_clause: /* from_clause  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_opt_where: /* opt_where  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_opt_group: /* opt_group  */
            { delete (((*yyvaluep).group_t)); }
        break;

    case YYSYMBOL_opt_having: /* opt_having  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_opt_order: /* opt_order  */
            {
	if ((((*yyvaluep).order_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).order_vec))->size(); ++var) {
				delete (((*yyvaluep).order_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).order_vec));
}
        break;

    case YYSYMBOL_order_list: /* order_list  */
            {
	if ((((*yyvaluep).order_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).order_vec))->size(); ++var) {
				delete (((*yyvaluep).order_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).order_vec));
}
        break;

    case YYSYMBOL_order_desc: /* order_desc  */
            { delete (((*yyvaluep).order)); }
        break;

    case YYSYMBOL_opt_order_type: /* opt_order_type  */
            { }
        break;

    case YYSYMBOL_opt_top: /* opt_top  */
            { delete (((*yyvaluep).limit)); }
        break;

    case YYSYMBOL_opt_limit: /* opt_limit  */
            { delete (((*yyvaluep).limit)); }
        break;

    case YYSYMBOL_expr_list: /* expr_list  */
            {
	if ((((*yyvaluep).expr_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).expr_vec))->size(); ++var) {
				delete (((*yyvaluep).expr_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).expr_vec));
}
        break;

    case YYSYMBOL_literal_list: /* literal_list  */
            {
	if ((((*yyvaluep).expr_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).expr_vec))->size(); ++var) {
				delete (((*yyvaluep).expr_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).expr_vec));
}
        break;

    case YYSYMBOL_expr_alias: /* expr_alias  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_expr: /* expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_operand: /* operand  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_scalar_expr: /* scalar_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_unary_expr: /* unary_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_binary_expr: /* binary_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_logic_expr: /* logic_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_in_expr: /* in_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_case_expr: /* case_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_case_list: /* case_list  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_exists_expr: /* exists_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_comp_expr: /* comp_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_function_expr: /* function_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_array_expr: /* array_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_array_index: /* array_index  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_between_expr: /* between_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_column_name: /* column_name  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_literal: /* literal  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_string_literal: /* string_literal  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_num_literal: /* num_literal  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_int_literal: /* int_literal  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_null_literal: /* null_literal  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_param_expr: /* param_expr  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_table_ref: /* table_ref  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_table_ref_atomic: /* table_ref_atomic  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_nonjoin_table_ref_atomic: /* nonjoin_table_ref_atomic  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_table_ref_commalist: /* table_ref_commalist  */
            {
	if ((((*yyvaluep).table_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).table_vec))->size(); ++var) {
				delete (((*yyvaluep).table_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).table_vec));
}
        break;

    case YYSYMBOL_table_ref_name: /* table_ref_name  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_table_ref_name_no_alias: /* table_ref_name_no_alias  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_table_name: /* table_name  */
            { free( (((*yyvaluep).table_name).name) ); free( (((*yyvaluep).table_name).schema) ); }
        break;

    case YYSYMBOL_alias: /* alias  */
            { free( (((*yyvaluep).sval)) ); }
        break;

    case YYSYMBOL_opt_alias: /* opt_alias  */
            { free( (((*yyvaluep).sval)) ); }
        break;

    case YYSYMBOL_join_clause: /* join_clause  */
            { delete (((*yyvaluep).table)); }
        break;

    case YYSYMBOL_opt_join_type: /* opt_join_type  */
            { }
        break;

    case YYSYMBOL_join_condition: /* join_condition  */
            { delete (((*yyvaluep).expr)); }
        break;

    case YYSYMBOL_ident_commalist: /* ident_commalist  */
            {
	if ((((*yyvaluep).str_vec)) != 0) {
			//SQLStatement* stmt
			for (int var = 0; var < (((*yyvaluep).str_vec))->size(); ++var) {
				delete (((*yyvaluep).str_vec))->at(var);
			}
		//for (SQLStatement ptr : *($$)) {			delete ptr;		}
	}
	delete (((*yyvaluep).str_vec));
}
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (hsql::SQLParserResult* result, yyscan_t scanner)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined HSQL_LTYPE_IS_TRIVIAL && HSQL_LTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = SQL_HSQL_EMPTY; /* Cause a token to be read.  */


/* User initialization code.  */
{
	// Initialize
	yylloc.first_column = 0;
	yylloc.last_column = 0;
	yylloc.first_line = 0;
	yylloc.last_line = 0;
	yylloc.total_column = 0;
	yylloc.string_length = 0;
}


  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == SQL_HSQL_EMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, scanner);
    }

  if (yychar <= SQL_YYEOF)
    {
      yychar = SQL_YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == SQL_HSQL_error)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = SQL_HSQL_UNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = SQL_HSQL_EMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* input: statement_list opt_semicolon  */
                                             {
		// trdm 2022-03-27 19:19:56  
		for (int var = 0; var < (yyvsp[-1].stmt_vec)->size(); ++var) {
			result->addStatement((yyvsp[-1].stmt_vec)->at(var));
		}
		// Transfers ownership of the statement.
		    // for (SQLStatement* stmt : *$1) {				result->addStatement(stmt);			}

			unsigned int param_id = 0;
			void* param;
			for (int var = 0; var < yyloc.param_list.size(); ++var) {
				param = yyloc.param_list.at(0);
//			}
//			for (void* param : yyloc.param_list) {
				if (param != 0) {
					Expr* expr = (Expr*) param;
					expr->ival = param_id;
					result->addParameter(expr);
					++param_id;
				}
			}
			delete (yyvsp[-1].stmt_vec);
		}
    break;

  case 3: /* statement_list: statement  */
                          {
			(yyvsp[0].statement)->stringLength = yylloc.string_length;
			yylloc.string_length = 0;
			(yyval.stmt_vec) = new std::vector<SQLStatement*>();
			(yyval.stmt_vec)->push_back((yyvsp[0].statement));
		}
    break;

  case 4: /* statement_list: statement_list ';' statement  */
                                             {
			(yyvsp[0].statement)->stringLength = yylloc.string_length;
			yylloc.string_length = 0;
			(yyvsp[-2].stmt_vec)->push_back((yyvsp[0].statement));
			(yyval.stmt_vec) = (yyvsp[-2].stmt_vec);
		}
    break;

  case 5: /* statement: prepare_statement opt_hints  */
                                            {
			(yyval.statement) = (yyvsp[-1].prep_stmt);
			(yyval.statement)->hints = (yyvsp[0].expr_vec);
		}
    break;

  case 6: /* statement: preparable_statement opt_hints  */
                                               {
			(yyval.statement) = (yyvsp[-1].statement);
			(yyval.statement)->hints = (yyvsp[0].expr_vec);
		}
    break;

  case 7: /* statement: show_statement  */
                               {
			(yyval.statement) = (yyvsp[0].show_stmt);
		}
    break;

  case 8: /* preparable_statement: select_statement  */
                                 { (yyval.statement) = (yyvsp[0].select_stmt); }
    break;

  case 9: /* preparable_statement: import_statement  */
                                 { (yyval.statement) = (yyvsp[0].import_stmt); }
    break;

  case 10: /* preparable_statement: create_statement  */
                                 { (yyval.statement) = (yyvsp[0].create_stmt); }
    break;

  case 11: /* preparable_statement: insert_statement  */
                                 { (yyval.statement) = (yyvsp[0].insert_stmt); }
    break;

  case 12: /* preparable_statement: delete_statement  */
                                 { (yyval.statement) = (yyvsp[0].delete_stmt); }
    break;

  case 13: /* preparable_statement: truncate_statement  */
                                   { (yyval.statement) = (yyvsp[0].delete_stmt); }
    break;

  case 14: /* preparable_statement: update_statement  */
                                 { (yyval.statement) = (yyvsp[0].update_stmt); }
    break;

  case 15: /* preparable_statement: drop_statement  */
                               { (yyval.statement) = (yyvsp[0].drop_stmt); }
    break;

  case 16: /* preparable_statement: execute_statement  */
                                  { (yyval.statement) = (yyvsp[0].exec_stmt); }
    break;

  case 17: /* opt_hints: WITH HINT '(' hint_list ')'  */
                                { (yyval.expr_vec) = (yyvsp[-1].expr_vec); }
    break;

  case 18: /* opt_hints: %empty  */
                { (yyval.expr_vec) = 0; }
    break;

  case 19: /* hint_list: hint  */
               { (yyval.expr_vec) = new std::vector<Expr*>(); (yyval.expr_vec)->push_back((yyvsp[0].expr)); }
    break;

  case 20: /* hint_list: hint_list ',' hint  */
                             { (yyvsp[-2].expr_vec)->push_back((yyvsp[0].expr)); (yyval.expr_vec) = (yyvsp[-2].expr_vec); }
    break;

  case 21: /* hint: IDENTIFIER  */
                           {
			(yyval.expr) = Expr::make(kExprHint);
			(yyval.expr)->name = (yyvsp[0].sval);
		}
    break;

  case 22: /* hint: IDENTIFIER '(' literal_list ')'  */
                                          {
			(yyval.expr) = Expr::make(kExprHint);
			(yyval.expr)->name = (yyvsp[-3].sval);
			(yyval.expr)->exprList = (yyvsp[-1].expr_vec);
		}
    break;

  case 23: /* prepare_statement: PREPARE IDENTIFIER FROM prepare_target_query  */
                                                             {
			(yyval.prep_stmt) = new PrepareStatement();
			(yyval.prep_stmt)->name = (yyvsp[-2].sval);
			(yyval.prep_stmt)->query = (yyvsp[0].sval);
		}
    break;

  case 25: /* execute_statement: EXECUTE IDENTIFIER  */
                                   {
			(yyval.exec_stmt) = new ExecuteStatement();
			(yyval.exec_stmt)->name = (yyvsp[0].sval);
		}
    break;

  case 26: /* execute_statement: EXECUTE IDENTIFIER '(' literal_list ')'  */
                                                        {
			(yyval.exec_stmt) = new ExecuteStatement();
			(yyval.exec_stmt)->name = (yyvsp[-3].sval);
			(yyval.exec_stmt)->parameters = (yyvsp[-1].expr_vec);
		}
    break;

  case 27: /* import_statement: IMPORT FROM import_file_type FILE file_path INTO table_name  */
                                                                            {
			(yyval.import_stmt) = new ImportStatement((ImportType) (yyvsp[-4].uval));
			(yyval.import_stmt)->filePath = (yyvsp[-2].sval);
			(yyval.import_stmt)->schema = (yyvsp[0].table_name).schema;
			(yyval.import_stmt)->tableName = (yyvsp[0].table_name).name;
		}
    break;

  case 28: /* import_file_type: CSV  */
                    { (yyval.uval) = kImportCSV; }
    break;

  case 29: /* file_path: string_literal  */
                               { (yyval.sval) = strdup((yyvsp[0].expr)->name); delete (yyvsp[0].expr); }
    break;

  case 30: /* show_statement: SHOW TABLES  */
                            {
			(yyval.show_stmt) = new ShowStatement(kShowTables);
		}
    break;

  case 31: /* show_statement: SHOW COLUMNS table_name  */
                                        {
			(yyval.show_stmt) = new ShowStatement(kShowColumns);
			(yyval.show_stmt)->schema = (yyvsp[0].table_name).schema;
			(yyval.show_stmt)->name = (yyvsp[0].table_name).name;
		}
    break;

  case 32: /* create_statement: CREATE TABLE opt_not_exists table_name FROM TBL FILE file_path  */
                                                                               {
			(yyval.create_stmt) = new CreateStatement(kCreateTableFromTbl);
			(yyval.create_stmt)->ifNotExists = (yyvsp[-5].bval);
			(yyval.create_stmt)->schema = (yyvsp[-4].table_name).schema;
			(yyval.create_stmt)->tableName = (yyvsp[-4].table_name).name;
			(yyval.create_stmt)->filePath = (yyvsp[0].sval);
		}
    break;

  case 33: /* create_statement: CREATE TABLE opt_not_exists table_name '(' column_def_commalist ')'  */
                                                                                    {
			(yyval.create_stmt) = new CreateStatement(kCreateTable);
			(yyval.create_stmt)->ifNotExists = (yyvsp[-4].bval);
			(yyval.create_stmt)->schema = (yyvsp[-3].table_name).schema;
			(yyval.create_stmt)->tableName = (yyvsp[-3].table_name).name;
			(yyval.create_stmt)->columns = (yyvsp[-1].column_vec);
		}
    break;

  case 34: /* create_statement: CREATE VIEW opt_not_exists table_name opt_column_list AS select_statement  */
                                                                                          {
			(yyval.create_stmt) = new CreateStatement(kCreateView);
			(yyval.create_stmt)->ifNotExists = (yyvsp[-4].bval);
			(yyval.create_stmt)->schema = (yyvsp[-3].table_name).schema;
			(yyval.create_stmt)->tableName = (yyvsp[-3].table_name).name;
			(yyval.create_stmt)->viewColumns = (yyvsp[-2].str_vec);
			(yyval.create_stmt)->select = (yyvsp[0].select_stmt);
		}
    break;

  case 35: /* opt_not_exists: IF NOT EXISTS  */
                              { (yyval.bval) = true; }
    break;

  case 36: /* opt_not_exists: %empty  */
                            { (yyval.bval) = false; }
    break;

  case 37: /* column_def_commalist: column_def  */
                           { (yyval.column_vec) = new std::vector<ColumnDefinition*>(); (yyval.column_vec)->push_back((yyvsp[0].column_t)); }
    break;

  case 38: /* column_def_commalist: column_def_commalist ',' column_def  */
                                                    { (yyvsp[-2].column_vec)->push_back((yyvsp[0].column_t)); (yyval.column_vec) = (yyvsp[-2].column_vec); }
    break;

  case 39: /* column_def: IDENTIFIER column_type  */
                                       {
			(yyval.column_t) = new ColumnDefinition((yyvsp[-1].sval), (ColumnDefinition::DataType) (yyvsp[0].uval));
		}
    break;

  case 40: /* column_type: INT  */
                    { (yyval.uval) = ColumnDefinition::INT; }
    break;

  case 41: /* column_type: INTEGER  */
                        { (yyval.uval) = ColumnDefinition::INT; }
    break;

  case 42: /* column_type: DOUBLE  */
                       { (yyval.uval) = ColumnDefinition::DOUBLE; }
    break;

  case 43: /* column_type: TEXT  */
                     { (yyval.uval) = ColumnDefinition::TEXT; }
    break;

  case 44: /* drop_statement: DROP TABLE opt_exists table_name  */
                                                 {
			(yyval.drop_stmt) = new DropStatement(kDropTable);
			(yyval.drop_stmt)->ifExists = (yyvsp[-1].bval);
			(yyval.drop_stmt)->schema = (yyvsp[0].table_name).schema;
			(yyval.drop_stmt)->name = (yyvsp[0].table_name).name;
		}
    break;

  case 45: /* drop_statement: DROP VIEW opt_exists table_name  */
                                                {
			(yyval.drop_stmt) = new DropStatement(kDropView);
			(yyval.drop_stmt)->ifExists = (yyvsp[-1].bval);
			(yyval.drop_stmt)->schema = (yyvsp[0].table_name).schema;
			(yyval.drop_stmt)->name = (yyvsp[0].table_name).name;
		}
    break;

  case 46: /* drop_statement: DEALLOCATE PREPARE IDENTIFIER  */
                                              {
			(yyval.drop_stmt) = new DropStatement(kDropPreparedStatement);
			(yyval.drop_stmt)->ifExists = false;
			(yyval.drop_stmt)->name = (yyvsp[0].sval);
		}
    break;

  case 47: /* opt_exists: IF EXISTS  */
                            { (yyval.bval) = true; }
    break;

  case 48: /* opt_exists: %empty  */
                            { (yyval.bval) = false; }
    break;

  case 49: /* delete_statement: DELETE FROM table_name opt_where  */
                                                 {
			(yyval.delete_stmt) = new DeleteStatement();
			(yyval.delete_stmt)->schema = (yyvsp[-1].table_name).schema;
			(yyval.delete_stmt)->tableName = (yyvsp[-1].table_name).name;
			(yyval.delete_stmt)->expr = (yyvsp[0].expr);
		}
    break;

  case 50: /* truncate_statement: TRUNCATE table_name  */
                                    {
			(yyval.delete_stmt) = new DeleteStatement();
			(yyval.delete_stmt)->schema = (yyvsp[0].table_name).schema;
			(yyval.delete_stmt)->tableName = (yyvsp[0].table_name).name;
		}
    break;

  case 51: /* insert_statement: INSERT INTO table_name opt_column_list VALUES '(' literal_list ')'  */
                                                                                   {
			(yyval.insert_stmt) = new InsertStatement(kInsertValues);
			(yyval.insert_stmt)->schema = (yyvsp[-5].table_name).schema;
			(yyval.insert_stmt)->tableName = (yyvsp[-5].table_name).name;
			(yyval.insert_stmt)->columns = (yyvsp[-4].str_vec);
			(yyval.insert_stmt)->values = (yyvsp[-1].expr_vec);
		}
    break;

  case 52: /* insert_statement: INSERT INTO table_name opt_column_list select_no_paren  */
                                                                       {
			(yyval.insert_stmt) = new InsertStatement(kInsertSelect);
			(yyval.insert_stmt)->schema = (yyvsp[-2].table_name).schema;
			(yyval.insert_stmt)->tableName = (yyvsp[-2].table_name).name;
			(yyval.insert_stmt)->columns = (yyvsp[-1].str_vec);
			(yyval.insert_stmt)->select = (yyvsp[0].select_stmt);
		}
    break;

  case 53: /* opt_column_list: '(' ident_commalist ')'  */
                                        { (yyval.str_vec) = (yyvsp[-1].str_vec); }
    break;

  case 54: /* opt_column_list: %empty  */
                            { (yyval.str_vec) = 0; }
    break;

  case 55: /* update_statement: UPDATE table_ref_name_no_alias SET update_clause_commalist opt_where  */
                                                                             {
		(yyval.update_stmt) = new UpdateStatement();
		(yyval.update_stmt)->table = (yyvsp[-3].table);
		(yyval.update_stmt)->updates = (yyvsp[-1].update_vec);
		(yyval.update_stmt)->where = (yyvsp[0].expr);
	}
    break;

  case 56: /* update_clause_commalist: update_clause  */
                              { (yyval.update_vec) = new std::vector<UpdateClause*>(); (yyval.update_vec)->push_back((yyvsp[0].update_t)); }
    break;

  case 57: /* update_clause_commalist: update_clause_commalist ',' update_clause  */
                                                          { (yyvsp[-2].update_vec)->push_back((yyvsp[0].update_t)); (yyval.update_vec) = (yyvsp[-2].update_vec); }
    break;

  case 58: /* update_clause: IDENTIFIER '=' expr  */
                                    {
			(yyval.update_t) = new UpdateClause();
			(yyval.update_t)->column = (yyvsp[-2].sval);
			(yyval.update_t)->value = (yyvsp[0].expr);
		}
    break;

  case 61: /* select_statement: select_with_paren set_operator select_paren_or_clause opt_order opt_limit  */
                                                                                          {
			// TODO: allow multiple unions (through linked list)
			// TODO: capture type of set_operator
			// TODO: might overwrite order and limit of first select here
			(yyval.select_stmt) = (yyvsp[-4].select_stmt);
			(yyval.select_stmt)->unionSelect = (yyvsp[-2].select_stmt);
			(yyval.select_stmt)->order = (yyvsp[-1].order_vec);

			// Limit could have been set by TOP.
			if ((yyvsp[0].limit) != 0) {
				delete (yyval.select_stmt)->limit;
				(yyval.select_stmt)->limit = (yyvsp[0].limit);
			}
		}
    break;

  case 62: /* select_with_paren: '(' select_no_paren ')'  */
                                        { (yyval.select_stmt) = (yyvsp[-1].select_stmt); }
    break;

  case 63: /* select_with_paren: '(' select_with_paren ')'  */
                                          { (yyval.select_stmt) = (yyvsp[-1].select_stmt); }
    break;

  case 66: /* select_no_paren: select_clause opt_order opt_limit  */
                                                  {
			(yyval.select_stmt) = (yyvsp[-2].select_stmt);
			(yyval.select_stmt)->order = (yyvsp[-1].order_vec);

			// Limit could have been set by TOP.
			if ((yyvsp[0].limit) != 0) {
				delete (yyval.select_stmt)->limit;
				(yyval.select_stmt)->limit = (yyvsp[0].limit);
			}
		}
    break;

  case 67: /* select_no_paren: select_clause set_operator select_paren_or_clause opt_order opt_limit  */
                                                                                      {
			// TODO: allow multiple unions (through linked list)
			// TODO: capture type of set_operator
			// TODO: might overwrite order and limit of first select here
			(yyval.select_stmt) = (yyvsp[-4].select_stmt);
			(yyval.select_stmt)->unionSelect = (yyvsp[-2].select_stmt);
			(yyval.select_stmt)->order = (yyvsp[-1].order_vec);

			// Limit could have been set by TOP.
			if ((yyvsp[0].limit) != 0) {
				delete (yyval.select_stmt)->limit;
				(yyval.select_stmt)->limit = (yyvsp[0].limit);
			}
		}
    break;

  case 74: /* select_clause: SELECT opt_top opt_distinct select_list from_clause opt_where opt_group  */
                                                                                        {
			(yyval.select_stmt) = new SelectStatement();
			(yyval.select_stmt)->limit = (yyvsp[-5].limit);
			(yyval.select_stmt)->selectDistinct = (yyvsp[-4].bval);
			(yyval.select_stmt)->selectList = (yyvsp[-3].expr_vec);
			(yyval.select_stmt)->fromTable = (yyvsp[-2].table);
			(yyval.select_stmt)->whereClause = (yyvsp[-1].expr);
			(yyval.select_stmt)->groupBy = (yyvsp[0].group_t);
		}
    break;

  case 75: /* opt_distinct: DISTINCT  */
                         { (yyval.bval) = true; }
    break;

  case 76: /* opt_distinct: %empty  */
                            { (yyval.bval) = false; }
    break;

  case 78: /* from_clause: FROM table_ref  */
                               { (yyval.table) = (yyvsp[0].table); }
    break;

  case 79: /* opt_where: WHERE expr  */
                           { (yyval.expr) = (yyvsp[0].expr); }
    break;

  case 80: /* opt_where: %empty  */
                            { (yyval.expr) = 0; }
    break;

  case 81: /* opt_group: GROUP BY expr_list opt_having  */
                                              {
			(yyval.group_t) = new GroupByDescription();
			(yyval.group_t)->columns = (yyvsp[-1].expr_vec);
			(yyval.group_t)->having = (yyvsp[0].expr);
		}
    break;

  case 82: /* opt_group: %empty  */
                            { (yyval.group_t) = 0; }
    break;

  case 83: /* opt_having: HAVING expr  */
                            { (yyval.expr) = (yyvsp[0].expr); }
    break;

  case 84: /* opt_having: %empty  */
                            { (yyval.expr) = 0; }
    break;

  case 85: /* opt_order: ORDER BY order_list  */
                                    { (yyval.order_vec) = (yyvsp[0].order_vec); }
    break;

  case 86: /* opt_order: %empty  */
                            { (yyval.order_vec) = 0; }
    break;

  case 87: /* order_list: order_desc  */
                           { (yyval.order_vec) = new std::vector<OrderDescription*>(); (yyval.order_vec)->push_back((yyvsp[0].order)); }
    break;

  case 88: /* order_list: order_list ',' order_desc  */
                                          { (yyvsp[-2].order_vec)->push_back((yyvsp[0].order)); (yyval.order_vec) = (yyvsp[-2].order_vec); }
    break;

  case 89: /* order_desc: expr opt_order_type  */
                                    { (yyval.order) = new OrderDescription((yyvsp[0].order_type), (yyvsp[-1].expr)); }
    break;

  case 90: /* opt_order_type: ASC  */
                    { (yyval.order_type) = kOrderAsc; }
    break;

  case 91: /* opt_order_type: DESC  */
                     { (yyval.order_type) = kOrderDesc; }
    break;

  case 92: /* opt_order_type: %empty  */
                            { (yyval.order_type) = kOrderAsc; }
    break;

  case 93: /* opt_top: TOP int_literal  */
                                { (yyval.limit) = new LimitDescription((yyvsp[0].expr)->ival, kNoOffset); delete (yyvsp[0].expr); }
    break;

  case 94: /* opt_top: %empty  */
                            { (yyval.limit) = 0; }
    break;

  case 95: /* opt_limit: LIMIT int_literal  */
                                  { (yyval.limit) = new LimitDescription((yyvsp[0].expr)->ival, kNoOffset); delete (yyvsp[0].expr); }
    break;

  case 96: /* opt_limit: LIMIT int_literal OFFSET int_literal  */
                                                     { (yyval.limit) = new LimitDescription((yyvsp[-2].expr)->ival, (yyvsp[0].expr)->ival); delete (yyvsp[-2].expr); delete (yyvsp[0].expr); }
    break;

  case 97: /* opt_limit: %empty  */
                            { (yyval.limit) = 0; }
    break;

  case 98: /* expr_list: expr_alias  */
                           { (yyval.expr_vec) = new std::vector<Expr*>(); (yyval.expr_vec)->push_back((yyvsp[0].expr)); }
    break;

  case 99: /* expr_list: expr_list ',' expr_alias  */
                                         { (yyvsp[-2].expr_vec)->push_back((yyvsp[0].expr)); (yyval.expr_vec) = (yyvsp[-2].expr_vec); }
    break;

  case 100: /* literal_list: literal  */
                        { (yyval.expr_vec) = new std::vector<Expr*>(); (yyval.expr_vec)->push_back((yyvsp[0].expr)); }
    break;

  case 101: /* literal_list: literal_list ',' literal  */
                                         { (yyvsp[-2].expr_vec)->push_back((yyvsp[0].expr)); (yyval.expr_vec) = (yyvsp[-2].expr_vec); }
    break;

  case 102: /* expr_alias: expr opt_alias  */
                               {
			(yyval.expr) = (yyvsp[-1].expr);
			(yyval.expr)->alias = (yyvsp[0].sval);
		}
    break;

  case 108: /* operand: '(' expr ')'  */
                             { (yyval.expr) = (yyvsp[-1].expr); }
    break;

  case 116: /* operand: '(' select_no_paren ')'  */
                                        { (yyval.expr) = Expr::makeSelect((yyvsp[-1].select_stmt)); }
    break;

  case 119: /* unary_expr: '-' operand  */
                            { (yyval.expr) = Expr::makeOpUnary(kOpUnaryMinus, (yyvsp[0].expr)); }
    break;

  case 120: /* unary_expr: NOT operand  */
                            { (yyval.expr) = Expr::makeOpUnary(kOpNot, (yyvsp[0].expr)); }
    break;

  case 121: /* unary_expr: operand ISNULL  */
                               { (yyval.expr) = Expr::makeOpUnary(kOpIsNull, (yyvsp[-1].expr)); }
    break;

  case 122: /* unary_expr: operand IS NULL  */
                                { (yyval.expr) = Expr::makeOpUnary(kOpIsNull, (yyvsp[-2].expr)); }
    break;

  case 123: /* unary_expr: operand IS NOT NULL  */
                                    { (yyval.expr) = Expr::makeOpUnary(kOpNot, Expr::makeOpUnary(kOpIsNull, (yyvsp[-3].expr))); }
    break;

  case 125: /* binary_expr: operand '-' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpMinus, (yyvsp[0].expr)); }
    break;

  case 126: /* binary_expr: operand '+' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpPlus, (yyvsp[0].expr)); }
    break;

  case 127: /* binary_expr: operand '/' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpSlash, (yyvsp[0].expr)); }
    break;

  case 128: /* binary_expr: operand '*' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpAsterisk, (yyvsp[0].expr)); }
    break;

  case 129: /* binary_expr: operand '%' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpPercentage, (yyvsp[0].expr)); }
    break;

  case 130: /* binary_expr: operand '^' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpCaret, (yyvsp[0].expr)); }
    break;

  case 131: /* binary_expr: operand LIKE operand  */
                                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpLike, (yyvsp[0].expr)); }
    break;

  case 132: /* binary_expr: operand NOT LIKE operand  */
                                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-3].expr), kOpNotLike, (yyvsp[0].expr)); }
    break;

  case 133: /* binary_expr: operand ILIKE operand  */
                                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpILike, (yyvsp[0].expr)); }
    break;

  case 134: /* binary_expr: operand CONCAT operand  */
                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpConcat, (yyvsp[0].expr)); }
    break;

  case 135: /* logic_expr: expr AND expr  */
                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpAnd, (yyvsp[0].expr)); }
    break;

  case 136: /* logic_expr: expr OR expr  */
                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpOr, (yyvsp[0].expr)); }
    break;

  case 137: /* in_expr: operand IN '(' expr_list ')'  */
                                                                { (yyval.expr) = Expr::makeInOperator((yyvsp[-4].expr), (yyvsp[-1].expr_vec)); }
    break;

  case 138: /* in_expr: operand NOT IN '(' expr_list ')'  */
                                                                { (yyval.expr) = Expr::makeOpUnary(kOpNot, Expr::makeInOperator((yyvsp[-5].expr), (yyvsp[-1].expr_vec))); }
    break;

  case 139: /* in_expr: operand IN '(' select_no_paren ')'  */
                                                                { (yyval.expr) = Expr::makeInOperator((yyvsp[-4].expr), (yyvsp[-1].select_stmt)); }
    break;

  case 140: /* in_expr: operand NOT IN '(' select_no_paren ')'  */
                                                        { (yyval.expr) = Expr::makeOpUnary(kOpNot, Expr::makeInOperator((yyvsp[-5].expr), (yyvsp[-1].select_stmt))); }
    break;

  case 141: /* case_expr: CASE expr case_list END  */
                                                        { (yyval.expr) = Expr::makeCase((yyvsp[-2].expr), (yyvsp[-1].expr), 0); }
    break;

  case 142: /* case_expr: CASE expr case_list ELSE expr END  */
                                                        { (yyval.expr) = Expr::makeCase((yyvsp[-4].expr), (yyvsp[-3].expr), (yyvsp[-1].expr)); }
    break;

  case 143: /* case_expr: CASE case_list END  */
                                                                { (yyval.expr) = Expr::makeCase(0, (yyvsp[-1].expr), 0); }
    break;

  case 144: /* case_expr: CASE case_list ELSE expr END  */
                                                        { (yyval.expr) = Expr::makeCase(0, (yyvsp[-3].expr), (yyvsp[-1].expr)); }
    break;

  case 145: /* case_list: WHEN expr THEN expr  */
                                                 { (yyval.expr) = Expr::makeCaseList(Expr::makeCaseListElement((yyvsp[-2].expr), (yyvsp[0].expr))); }
    break;

  case 146: /* case_list: case_list WHEN expr THEN expr  */
                                                 { (yyval.expr) = Expr::caseListAppend((yyvsp[-4].expr), Expr::makeCaseListElement((yyvsp[-2].expr), (yyvsp[0].expr))); }
    break;

  case 147: /* exists_expr: EXISTS '(' select_no_paren ')'  */
                                               { (yyval.expr) = Expr::makeExists((yyvsp[-1].select_stmt)); }
    break;

  case 148: /* exists_expr: NOT EXISTS '(' select_no_paren ')'  */
                                                   { (yyval.expr) = Expr::makeOpUnary(kOpNot, Expr::makeExists((yyvsp[-1].select_stmt))); }
    break;

  case 149: /* comp_expr: operand '=' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpEquals, (yyvsp[0].expr)); }
    break;

  case 150: /* comp_expr: operand EQUALS operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpEquals, (yyvsp[0].expr)); }
    break;

  case 151: /* comp_expr: operand NOTEQUALS operand  */
                                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpNotEquals, (yyvsp[0].expr)); }
    break;

  case 152: /* comp_expr: operand '<' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpLess, (yyvsp[0].expr)); }
    break;

  case 153: /* comp_expr: operand '>' operand  */
                                                        { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpGreater, (yyvsp[0].expr)); }
    break;

  case 154: /* comp_expr: operand LESSEQ operand  */
                                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpLessEq, (yyvsp[0].expr)); }
    break;

  case 155: /* comp_expr: operand GREATEREQ operand  */
                                                { (yyval.expr) = Expr::makeOpBinary((yyvsp[-2].expr), kOpGreaterEq, (yyvsp[0].expr)); }
    break;

  case 156: /* function_expr: IDENTIFIER '(' ')'  */
                                   { (yyval.expr) = Expr::makeFunctionRef((yyvsp[-2].sval), new std::vector<Expr*>(), false); }
    break;

  case 157: /* function_expr: IDENTIFIER '(' opt_distinct expr_list ')'  */
                                                          { (yyval.expr) = Expr::makeFunctionRef((yyvsp[-4].sval), (yyvsp[-1].expr_vec), (yyvsp[-2].bval)); }
    break;

  case 158: /* array_expr: ARRAY '[' expr_list ']'  */
                                        { (yyval.expr) = Expr::makeArray((yyvsp[-1].expr_vec)); }
    break;

  case 159: /* array_index: operand '[' int_literal ']'  */
                                            { (yyval.expr) = Expr::makeArrayIndex((yyvsp[-3].expr), (yyvsp[-1].expr)->ival); }
    break;

  case 160: /* between_expr: operand BETWEEN operand AND operand  */
                                                    { (yyval.expr) = Expr::makeBetween((yyvsp[-4].expr), (yyvsp[-2].expr), (yyvsp[0].expr)); }
    break;

  case 161: /* column_name: IDENTIFIER  */
                           { (yyval.expr) = Expr::makeColumnRef((yyvsp[0].sval)); }
    break;

  case 162: /* column_name: IDENTIFIER '.' IDENTIFIER  */
                                          { (yyval.expr) = Expr::makeColumnRef((yyvsp[-2].sval), (yyvsp[0].sval)); }
    break;

  case 163: /* column_name: '*'  */
                    { (yyval.expr) = Expr::makeStar(); }
    break;

  case 164: /* column_name: IDENTIFIER '.' '*'  */
                                   { (yyval.expr) = Expr::makeStar((yyvsp[-2].sval)); }
    break;

  case 169: /* string_literal: STRING  */
                       { (yyval.expr) = Expr::makeLiteral((yyvsp[0].sval)); }
    break;

  case 170: /* num_literal: FLOATVAL  */
                         { (yyval.expr) = Expr::makeLiteral((yyvsp[0].fval)); }
    break;

  case 172: /* int_literal: INTVAL  */
                       { (yyval.expr) = Expr::makeLiteral((yyvsp[0].ival)); }
    break;

  case 173: /* null_literal: NULL  */
                     { (yyval.expr) = Expr::makeNullLiteral(); }
    break;

  case 174: /* param_expr: '?'  */
                    {
			(yyval.expr) = Expr::makeParameter(yylloc.total_column);
			(yyval.expr)->ival2 = yyloc.param_list.size();
			yyloc.param_list.push_back((yyval.expr));
		}
    break;

  case 176: /* table_ref: table_ref_commalist ',' table_ref_atomic  */
                                                         {
			(yyvsp[-2].table_vec)->push_back((yyvsp[0].table));
			TableRef* tbl = new TableRef(kTableCrossProduct);
			tbl->list = (yyvsp[-2].table_vec);
			(yyval.table) = tbl;
		}
    break;

  case 180: /* nonjoin_table_ref_atomic: '(' select_statement ')' opt_alias  */
                                                   {
			TableRef* tbl = new TableRef(kTableSelect);
			tbl->select = (yyvsp[-2].select_stmt);
			tbl->alias = (yyvsp[0].sval);
			(yyval.table) = tbl;
		}
    break;

  case 181: /* table_ref_commalist: table_ref_atomic  */
                                 { (yyval.table_vec) = new std::vector<TableRef*>(); (yyval.table_vec)->push_back((yyvsp[0].table)); }
    break;

  case 182: /* table_ref_commalist: table_ref_commalist ',' table_ref_atomic  */
                                                         { (yyvsp[-2].table_vec)->push_back((yyvsp[0].table)); (yyval.table_vec) = (yyvsp[-2].table_vec); }
    break;

  case 183: /* table_ref_name: table_name opt_alias  */
                                     {
			TableRef* tbl = new TableRef(kTableName);
			tbl->schema = (yyvsp[-1].table_name).schema;
			tbl->name = (yyvsp[-1].table_name).name;
			tbl->alias = (yyvsp[0].sval);
			(yyval.table) = tbl;
		}
    break;

  case 184: /* table_ref_name_no_alias: table_name  */
                           {
			(yyval.table) = new TableRef(kTableName);
			(yyval.table)->schema = (yyvsp[0].table_name).schema;
			(yyval.table)->name = (yyvsp[0].table_name).name;
		}
    break;

  case 185: /* table_name: IDENTIFIER  */
                                          { (yyval.table_name).schema = 0; (yyval.table_name).name = (yyvsp[0].sval);}
    break;

  case 186: /* table_name: IDENTIFIER '.' IDENTIFIER  */
                                          { (yyval.table_name).schema = (yyvsp[-2].sval); (yyval.table_name).name = (yyvsp[0].sval); }
    break;

  case 187: /* alias: AS IDENTIFIER  */
                              { (yyval.sval) = (yyvsp[0].sval); }
    break;

  case 190: /* opt_alias: %empty  */
                            { (yyval.sval) = 0; }
    break;

  case 191: /* join_clause: table_ref_atomic NATURAL JOIN nonjoin_table_ref_atomic  */
                {
			(yyval.table) = new TableRef(kTableJoin);
			(yyval.table)->join = new JoinDefinition();
			(yyval.table)->join->type = kJoinNatural;
			(yyval.table)->join->left = (yyvsp[-3].table);
			(yyval.table)->join->right = (yyvsp[0].table);
		}
    break;

  case 192: /* join_clause: table_ref_atomic opt_join_type JOIN table_ref_atomic ON join_condition  */
                {
			(yyval.table) = new TableRef(kTableJoin);
			(yyval.table)->join = new JoinDefinition();
			(yyval.table)->join->type = (JoinType) (yyvsp[-4].uval);
			(yyval.table)->join->left = (yyvsp[-5].table);
			(yyval.table)->join->right = (yyvsp[-2].table);
			(yyval.table)->join->condition = (yyvsp[0].expr);
		}
    break;

  case 193: /* join_clause: table_ref_atomic opt_join_type JOIN table_ref_atomic USING '(' column_name ')'  */
                {
			(yyval.table) = new TableRef(kTableJoin);
			(yyval.table)->join = new JoinDefinition();
			(yyval.table)->join->type = (JoinType) (yyvsp[-6].uval);
			(yyval.table)->join->left = (yyvsp[-7].table);
			(yyval.table)->join->right = (yyvsp[-4].table);
			Expr* left_col = Expr::makeColumnRef(strdup((yyvsp[-1].expr)->name));
			if ((yyvsp[-1].expr)->alias != 0) left_col->alias = strdup((yyvsp[-1].expr)->alias);
			if ((yyvsp[-7].table)->getName() != 0) left_col->table = strdup((yyvsp[-7].table)->getName());
			Expr* right_col = Expr::makeColumnRef(strdup((yyvsp[-1].expr)->name));
			if ((yyvsp[-1].expr)->alias != 0) right_col->alias = strdup((yyvsp[-1].expr)->alias);
			if ((yyvsp[-4].table)->getName() != 0) right_col->table = strdup((yyvsp[-4].table)->getName());
			(yyval.table)->join->condition = Expr::makeOpBinary(left_col, kOpEquals, right_col);
			delete (yyvsp[-1].expr);
		}
    break;

  case 194: /* opt_join_type: INNER  */
                                { (yyval.uval) = kJoinInner; }
    break;

  case 195: /* opt_join_type: LEFT OUTER  */
                                { (yyval.uval) = kJoinLeft; }
    break;

  case 196: /* opt_join_type: LEFT  */
                                { (yyval.uval) = kJoinLeft; }
    break;

  case 197: /* opt_join_type: RIGHT OUTER  */
                                { (yyval.uval) = kJoinRight; }
    break;

  case 198: /* opt_join_type: RIGHT  */
                                { (yyval.uval) = kJoinRight; }
    break;

  case 199: /* opt_join_type: FULL OUTER  */
                                { (yyval.uval) = kJoinFull; }
    break;

  case 200: /* opt_join_type: OUTER  */
                                { (yyval.uval) = kJoinFull; }
    break;

  case 201: /* opt_join_type: FULL  */
                                { (yyval.uval) = kJoinFull; }
    break;

  case 202: /* opt_join_type: CROSS  */
                                { (yyval.uval) = kJoinCross; }
    break;

  case 203: /* opt_join_type: %empty  */
                                        { (yyval.uval) = kJoinInner; }
    break;

  case 207: /* ident_commalist: IDENTIFIER  */
                           { (yyval.str_vec) = new std::vector<char*>(); (yyval.str_vec)->push_back((yyvsp[0].sval)); }
    break;

  case 208: /* ident_commalist: ident_commalist ',' IDENTIFIER  */
                                               { (yyvsp[-2].str_vec)->push_back((yyvsp[0].sval)); (yyval.str_vec) = (yyvsp[-2].str_vec); }
    break;



      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == SQL_HSQL_EMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (&yylloc, result, scanner, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= SQL_YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == SQL_YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, result, scanner);
          yychar = SQL_HSQL_EMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, result, scanner);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, result, scanner, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != SQL_HSQL_EMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, result, scanner);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, result, scanner);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}


/*********************************
 ** Section 4: Additional C code
 *********************************/

/* empty */

