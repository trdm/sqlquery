/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_HSQL_BISON_PARSER_HPP_INCLUDED
# define YY_HSQL_BISON_PARSER_HPP_INCLUDED
/* Debug traces.  */
#ifndef HSQL_DEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define HSQL_DEBUG 1
#  else
#   define HSQL_DEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define HSQL_DEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined HSQL_DEBUG */
#if HSQL_DEBUG
extern int hsql_debug;
#endif
/* "%code requires" blocks.  */

// %code requires block

#include "../sql/statements.h"
#include "../SQLParserResult.h"
#include "parser_typedef.h"
#include "../defs.h"

// Auto update column and line number
#define YY_USER_ACTION \
		yylloc->first_line = yylloc->last_line; \
		yylloc->first_column = yylloc->last_column; \
		for(int i = 0; yytext[i] != '\0'; i++) { \
			yylloc->total_column++; \
			yylloc->string_length++; \
				if(yytext[i] == '\n') { \
						yylloc->last_line++; \
						yylloc->last_column = 0; \
				} \
				else { \
						yylloc->last_column++; \
				} \
		}


/* Token kinds.  */
#ifndef HSQL_TOKENTYPE
# define HSQL_TOKENTYPE
  enum hsql_tokentype
  {
    SQL_HSQL_EMPTY = -2,
    SQL_YYEOF = 0,                 /* "end of file"  */
    SQL_HSQL_error = 256,          /* error  */
    SQL_HSQL_UNDEF = 257,          /* "invalid token"  */
    SQL_IDENTIFIER = 258,          /* IDENTIFIER  */
    SQL_STRING = 259,              /* STRING  */
    SQL_FLOATVAL = 260,            /* FLOATVAL  */
    SQL_INTVAL = 261,              /* INTVAL  */
    SQL_DEALLOCATE = 262,          /* DEALLOCATE  */
    SQL_PARAMETERS = 263,          /* PARAMETERS  */
    SQL_INTERSECT = 264,           /* INTERSECT  */
    SQL_TEMPORARY = 265,           /* TEMPORARY  */
    SQL_TIMESTAMP = 266,           /* TIMESTAMP  */
    SQL_DISTINCT = 267,            /* DISTINCT  */
    SQL_NVARCHAR = 268,            /* NVARCHAR  */
    SQL_RESTRICT = 269,            /* RESTRICT  */
    SQL_TRUNCATE = 270,            /* TRUNCATE  */
    SQL_ANALYZE = 271,             /* ANALYZE  */
    SQL_BETWEEN = 272,             /* BETWEEN  */
    SQL_CASCADE = 273,             /* CASCADE  */
    SQL_COLUMNS = 274,             /* COLUMNS  */
    SQL_CONTROL = 275,             /* CONTROL  */
    SQL_DEFAULT = 276,             /* DEFAULT  */
    SQL_EXECUTE = 277,             /* EXECUTE  */
    SQL_EXPLAIN = 278,             /* EXPLAIN  */
    SQL_HISTORY = 279,             /* HISTORY  */
    SQL_INTEGER = 280,             /* INTEGER  */
    SQL_NATURAL = 281,             /* NATURAL  */
    SQL_PREPARE = 282,             /* PREPARE  */
    SQL_PRIMARY = 283,             /* PRIMARY  */
    SQL_SCHEMAS = 284,             /* SCHEMAS  */
    SQL_SPATIAL = 285,             /* SPATIAL  */
    SQL_VIRTUAL = 286,             /* VIRTUAL  */
    SQL_BEFORE = 287,              /* BEFORE  */
    SQL_COLUMN = 288,              /* COLUMN  */
    SQL_CREATE = 289,              /* CREATE  */
    SQL_DELETE = 290,              /* DELETE  */
    SQL_DIRECT = 291,              /* DIRECT  */
    SQL_DOUBLE = 292,              /* DOUBLE  */
    SQL_ESCAPE = 293,              /* ESCAPE  */
    SQL_EXCEPT = 294,              /* EXCEPT  */
    SQL_EXISTS = 295,              /* EXISTS  */
    SQL_GLOBAL = 296,              /* GLOBAL  */
    SQL_HAVING = 297,              /* HAVING  */
    SQL_IMPORT = 298,              /* IMPORT  */
    SQL_INSERT = 299,              /* INSERT  */
    SQL_ISNULL = 300,              /* ISNULL  */
    SQL_OFFSET = 301,              /* OFFSET  */
    SQL_RENAME = 302,              /* RENAME  */
    SQL_SCHEMA = 303,              /* SCHEMA  */
    SQL_SELECT = 304,              /* SELECT  */
    SQL_SORTED = 305,              /* SORTED  */
    SQL_TABLES = 306,              /* TABLES  */
    SQL_UNIQUE = 307,              /* UNIQUE  */
    SQL_UNLOAD = 308,              /* UNLOAD  */
    SQL_UPDATE = 309,              /* UPDATE  */
    SQL_VALUES = 310,              /* VALUES  */
    SQL_AFTER = 311,               /* AFTER  */
    SQL_ALTER = 312,               /* ALTER  */
    SQL_CROSS = 313,               /* CROSS  */
    SQL_DELTA = 314,               /* DELTA  */
    SQL_GROUP = 315,               /* GROUP  */
    SQL_INDEX = 316,               /* INDEX  */
    SQL_INNER = 317,               /* INNER  */
    SQL_LIMIT = 318,               /* LIMIT  */
    SQL_LOCAL = 319,               /* LOCAL  */
    SQL_MERGE = 320,               /* MERGE  */
    SQL_MINUS = 321,               /* MINUS  */
    SQL_ORDER = 322,               /* ORDER  */
    SQL_OUTER = 323,               /* OUTER  */
    SQL_RIGHT = 324,               /* RIGHT  */
    SQL_TABLE = 325,               /* TABLE  */
    SQL_UNION = 326,               /* UNION  */
    SQL_USING = 327,               /* USING  */
    SQL_WHERE = 328,               /* WHERE  */
    SQL_CALL = 329,                /* CALL  */
    SQL_CASE = 330,                /* CASE  */
    SQL_DATE = 331,                /* DATE  */
    SQL_DESC = 332,                /* DESC  */
    SQL_DROP = 333,                /* DROP  */
    SQL_ELSE = 334,                /* ELSE  */
    SQL_FILE = 335,                /* FILE  */
    SQL_FROM = 336,                /* FROM  */
    SQL_FULL = 337,                /* FULL  */
    SQL_HASH = 338,                /* HASH  */
    SQL_HINT = 339,                /* HINT  */
    SQL_INTO = 340,                /* INTO  */
    SQL_JOIN = 341,                /* JOIN  */
    SQL_LEFT = 342,                /* LEFT  */
    SQL_LIKE = 343,                /* LIKE  */
    SQL_LOAD = 344,                /* LOAD  */
    SQL_NULL = 345,                /* NULL  */
    SQL_PART = 346,                /* PART  */
    SQL_PLAN = 347,                /* PLAN  */
    SQL_SHOW = 348,                /* SHOW  */
    SQL_TEXT = 349,                /* TEXT  */
    SQL_THEN = 350,                /* THEN  */
    SQL_TIME = 351,                /* TIME  */
    SQL_VIEW = 352,                /* VIEW  */
    SQL_WHEN = 353,                /* WHEN  */
    SQL_WITH = 354,                /* WITH  */
    SQL_ADD = 355,                 /* ADD  */
    SQL_ALL = 356,                 /* ALL  */
    SQL_AND = 357,                 /* AND  */
    SQL_ASC = 358,                 /* ASC  */
    SQL_CSV = 359,                 /* CSV  */
    SQL_END = 360,                 /* END  */
    SQL_FOR = 361,                 /* FOR  */
    SQL_INT = 362,                 /* INT  */
    SQL_KEY = 363,                 /* KEY  */
    SQL_NOT = 364,                 /* NOT  */
    SQL_OFF = 365,                 /* OFF  */
    SQL_SET = 366,                 /* SET  */
    SQL_TBL = 367,                 /* TBL  */
    SQL_TOP = 368,                 /* TOP  */
    SQL_AS = 369,                  /* AS  */
    SQL_BY = 370,                  /* BY  */
    SQL_IF = 371,                  /* IF  */
    SQL_IN = 372,                  /* IN  */
    SQL_IS = 373,                  /* IS  */
    SQL_OF = 374,                  /* OF  */
    SQL_ON = 375,                  /* ON  */
    SQL_OR = 376,                  /* OR  */
    SQL_TO = 377,                  /* TO  */
    SQL_ARRAY = 378,               /* ARRAY  */
    SQL_CONCAT = 379,              /* CONCAT  */
    SQL_ILIKE = 380,               /* ILIKE  */
    SQL_EQUALS = 381,              /* EQUALS  */
    SQL_NOTEQUALS = 382,           /* NOTEQUALS  */
    SQL_LESS = 383,                /* LESS  */
    SQL_GREATER = 384,             /* GREATER  */
    SQL_LESSEQ = 385,              /* LESSEQ  */
    SQL_GREATEREQ = 386,           /* GREATEREQ  */
    SQL_NOTNULL = 387,             /* NOTNULL  */
    SQL_UMINUS = 388               /* UMINUS  */
  };
  typedef enum hsql_tokentype hsql_token_kind_t;
#endif

/* Value type.  */
#if ! defined HSQL_STYPE && ! defined HSQL_STYPE_IS_DECLARED
union HSQL_STYPE
{

	double fval;
	int64_t ival;
	char* sval;
	uintmax_t uval;
	bool bval;

	hsql::SQLStatement* statement;
	hsql::SelectStatement* 	select_stmt;
	hsql::ImportStatement* 	import_stmt;
	hsql::CreateStatement* 	create_stmt;
	hsql::InsertStatement* 	insert_stmt;
	hsql::DeleteStatement* 	delete_stmt;
	hsql::UpdateStatement* 	update_stmt;
	hsql::DropStatement*   	drop_stmt;
	hsql::PrepareStatement* prep_stmt;
	hsql::ExecuteStatement* exec_stmt;
	hsql::ShowStatement*    show_stmt;

	hsql::TableName table_name;
	hsql::TableRef* table;
	hsql::Expr* expr;
	hsql::OrderDescription* order;
	hsql::OrderType order_type;
	hsql::LimitDescription* limit;
	hsql::ColumnDefinition* column_t;
	hsql::GroupByDescription* group_t;
	hsql::UpdateClause* update_t;

	std::vector<hsql::SQLStatement*>* stmt_vec;

	std::vector<char*>* str_vec;
	std::vector<hsql::TableRef*>* table_vec;
	std::vector<hsql::ColumnDefinition*>* column_vec;
	std::vector<hsql::UpdateClause*>* update_vec;
	std::vector<hsql::Expr*>* expr_vec;
	std::vector<hsql::OrderDescription*>* order_vec;


};
typedef union HSQL_STYPE HSQL_STYPE;
# define HSQL_STYPE_IS_TRIVIAL 1
# define HSQL_STYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined HSQL_LTYPE && ! defined HSQL_LTYPE_IS_DECLARED
typedef struct HSQL_LTYPE HSQL_LTYPE;
struct HSQL_LTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define HSQL_LTYPE_IS_DECLARED 1
# define HSQL_LTYPE_IS_TRIVIAL 1
#endif




int hsql_parse (hsql::SQLParserResult* result, yyscan_t scanner);


#endif /* !YY_HSQL_BISON_PARSER_HPP_INCLUDED  */
