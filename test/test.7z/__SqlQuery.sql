CREATE VIEW w_stat AS SELECT count(stat.word) AS wc, stat.word AS w  FROM __Statistic AS stat  GROUP BY stat.word  ORDER BY wc DESC;

-- CREATE VIEW w_wsize_mm AS SELECT max(size) as max_size, min(size) as min_size FROM __wordSize;
-- size_CF - ������� ������� �� �� �������� ��� 1 ������.
CREATE VIEW w_dificlt AS SELECT word, size as w_size,size/(select min(size) as min_size from __wordSize) as size_idx, size/10000 as  size_CF  FROM __wordSize;


ALTER TABLE __Statistic ADD dates DATE;
update  __Statistic set dates = ('' || substr(trim(data_time),1,7) || '-' || substr(trim(data_time),8,2));

ALTER TABLE __Statistic ADD year Integer;
ALTER TABLE __Statistic ADD start_of_year Integer;
ALTER TABLE __Statistic ADD start_oy_2020 Integer;

update  __Statistic set dates = ('' || substr(trim(data_time),1,7) || '-' || substr(trim(data_time),8,2));
update __Statistic set year = substr(trim(data_time),1,4);
update __Statistic set start_of_year = julianday(dates) - julianday(dates,'start of year');
update __Statistic set start_oy_2020 = julianday(dates)-julianday(date('2020-01-01'));
update __Statistic set part = CASE WHEN part = ''       THEN '0'       ELSE part       END;

-- SELECT word, ('' || substr(trim(data_time),1,7) || '-' || substr(trim(data_time),8,2)) as data, data_time as dt from __Statistic
-- SELECT date('2022-03-28') as data, cast((julianday('now') - julianday('2022-03-28')) as Integer) as dd 
